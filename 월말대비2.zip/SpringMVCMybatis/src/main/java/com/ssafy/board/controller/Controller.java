package com.ssafy.board.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.ssafy.board.Board;
import com.ssafy.board.Service.Service;

@org.springframework.stereotype.Controller
public class Controller {
	
	@Autowired
	Service service;
	
	@GetMapping("boardInput.do")
	public String getInsert() {
		return "board/boardInsert";
	}
	
	@PostMapping("boardInsert.do")
	public String doInsert(Board board,Model model) {
		int result=service.insert(board);
		List<Board> list=service.selectAll();
		model.addAttribute("list",list);
		return "board/boardList";
	}
	
	@GetMapping("boardList.do")
	public String doSelectAll(Model model) {
		List<Board> list=service.selectAll();
		model.addAttribute("list",list);
		return "board/boardList";
		
	}

}
