package com.ssafy.board.Repository;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;

import com.ssafy.board.Board;

@org.springframework.stereotype.Repository
public class RepositoryImpl implements Repository{
	
	@Autowired
	SqlSession session;
	
	private final String ns="sql.board.";

	@Override
	public int insert(Board board) {
		String s=ns+"insert";
		return session.insert(s,board);
	}

	@Override
	public List<Board> selectAll() {
		String s=ns+"selectAll";
		return session.selectList(s);
	}

}
