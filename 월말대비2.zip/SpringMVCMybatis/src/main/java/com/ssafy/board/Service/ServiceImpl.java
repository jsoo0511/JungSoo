package com.ssafy.board.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.ssafy.board.Board;
import com.ssafy.board.Repository.Repository;

@org.springframework.stereotype.Service
public class ServiceImpl implements Service{

	@Autowired
	Repository repo;
	
	@Override
	public int insert(Board board) {
		return repo.insert(board);
	}

	@Override
	public List<Board> selectAll() {
		return repo.selectAll();
	}

}
