package com.ssafy.board.Service;

import java.util.List;

import com.ssafy.board.Board;

public interface Service {
	int insert(Board board);
	List<Board> selectAll();

}
