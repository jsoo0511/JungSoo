package com.ssafy.day1;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class FirstServlet
 */
@WebServlet("/FirstServlet")
public class FirstServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * 
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setAttribute("attr", "first");
		if(request.getParameter("type")!=null) {
			// forward로 두번째 서블릿으로 이동
			RequestDispatcher disp = request.getRequestDispatcher("second");
			// request와 response가 그대로 전달된다.
			disp.forward(request, response);
		}else {
			// sendredirect로 두번째 서블릿으로 이동
			// request와 response가 전달되지 않는다.
			response.sendRedirect("second");
		}
	}

	
	
	
	
	
	
	
	
	
}
