package com.ssafy.day1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class GuGuServlet
 */
@WebServlet("/GuGuServlet")
public class GuGuServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 파라미터에서 몇단을 출력할 지 가져온다.
		String danStr = request.getParameter("dan");
		// 문자열 --> 숫자 변환
		int dan = 1;
		if(danStr!=null) {
			dan = Integer.parseInt(danStr);
		}
		
		//  구구단 출력(response의 PrintWriter 활용)
		String result = new GuGuGenerator().getGugu(dan);
		PrintWriter out = response.getWriter();
		out.append(result);
	}

}
