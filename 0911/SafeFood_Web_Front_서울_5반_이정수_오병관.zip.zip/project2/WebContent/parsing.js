	let infoSrc = 'foodInfo.json';
	let nutritionSrc = 'FoodNutritionInfo.json';
	let foods = [];
	let foodsnutrition = [];
	let foodmaterial=[];
	$.getJSON(infoSrc, function(data) {
		for (var i = 0; i < data.foods.food.length; i++) {
			foods.push(data.foods.food[i]);
			let material=data.foods.food[i].material;
			foodmaterial.push(material.split(',',10));
		}
	})

	$.getJSON(nutritionSrc, function(data) {
		for (var i = 0; i < data.response.body.items.item.length; i++) {
			foodsnutrition.push(data.response.body.items.item[i]);
		}
	})