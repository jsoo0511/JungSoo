package com.ssafy.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.SAXException;

import com.ssafy.util.DBUtil;
import com.ssafy.util.FoodNutritionSAXHandler;
import com.ssafy.util.FoodSAXHandler;
import com.ssafy.util.FoodSaxParser;
import com.ssafy.vo.Food;
import com.ssafy.vo.FoodPageBean;
import com.ssafy.vo.SafeFoodException;



public class FoodDaoImpl implements FoodDao{
	private DBUtil util = DBUtil.getUtil();
	public FoodDaoImpl() {
		loadData();
	}

	/**
	 * 식품 영양학 정보와 식품 정보를  xml 파일에서 읽어온다.
	 * @throws SAXException 
	 * @throws ParserConfigurationException 
	 * 
	 */
	
	public void loadData(){
		FoodSaxParser fsp=new FoodSaxParser();
		List<Food> list=fsp.getFoods();

	  //  FoodNutritionSaxPaser를 이용하여 Food 데이터들을 가져온다
	  //  가져온 Food 리스트 데이터를 DB에 저장한다.
		String sql="insert into food values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		Connection con = null;
		PreparedStatement pstmt = null;
		int result = -1;
		try {			
			con = util.getConnection();
			con.setAutoCommit(false);
			for(Food food : list) {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1,food.getCode());
			pstmt.setString(2, food.getName());
			pstmt.setDouble(3, food.getSupportpereat());
			pstmt.setDouble(4, food.getCalory());
			pstmt.setDouble(5, food.getCarbo());
			pstmt.setDouble(6, food.getProtein());
			pstmt.setDouble(7, food.getFat());
			pstmt.setDouble(8, food.getSugar());
			pstmt.setDouble(9, food.getNatrium());
			pstmt.setDouble(10, food.getChole());
			pstmt.setDouble(11, food.getFattyacid());
			pstmt.setDouble(12, food.getTransfat());
			pstmt.setString(13, food.getMaker());
			pstmt.setString(14, food.getMaterial());
			pstmt.setString(15, food.getImg());
			pstmt.setString(16, food.getAllergy());
			result = pstmt.executeUpdate();
			System.out.println(result);
			}
			con.commit();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			
			util.close(pstmt);
			util.close(con);
		}
		
				
	}
	
	
	/**
	 * 검색 조건(key) 검색 단어(word)에 해당하는 식품 정보(Food)의 개수를 반환. 
	 * web에서 구현할 내용. 
	 * web에서 페이징 처리시 필요 
	 * @param bean  검색 조건과 검색 단어가 있는 객체
	 * @return 조회한  식품 개수
	 */
	public int foodCount(FoodPageBean  bean){
		int result = 0;
		Connection con = null;
		if (bean != null) {
			String key = bean.getKey();
			String word = bean.getWord();
			if (!key.equals("all") && word != null && !word.trim().equals("")) {
				if (key.equals("name")) {

					String sql = "select * from food where locate(?,name)";

					PreparedStatement pstmt = null;
					ResultSet rset = null;
					try {
						con = util.getConnection();
						pstmt = con.prepareStatement(sql);
						pstmt.setString(1, word);
						rset = pstmt.executeQuery();
						while (rset.next()) {
							result++;
						}
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} finally {
						util.close(rset);
						util.close(pstmt);
						util.close(con);
					}

				} else if (key.equals("maker")) {
					String sql = "select * from food where maker = ?";
					PreparedStatement pstmt = null;
					ResultSet rset = null;
					try {
						pstmt = con.prepareStatement(sql);
						pstmt.setString(1, word);
						rset = pstmt.executeQuery();
						while (rset.next()) {
							result++;
						}
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} finally {
						util.close(rset);
						util.close(pstmt);
						util.close(con);
					}

				} else if (key.equals("material")) {
					String sql = "select * from food where locate(?,material)";

					PreparedStatement pstmt = null;
					ResultSet rset = null;
					try {
						pstmt = con.prepareStatement(sql);
						pstmt.setString(1, word);
						rset = pstmt.executeQuery();
						while (rset.next()) {
							result++;
						}
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} finally {
						util.close(rset);
						util.close(pstmt);
						util.close(con);
					}
				}
			}
		}
		//구현하세요.
		return result;
	}
	
	/**
	 * 검색 조건(key) 검색 단어(word)에 해당하는 식품 정보(Food)를  검색해서 반환.  
	 * @param bean  검색 조건과 검색 단어가 있는 객체
	 * @return 조회한 식품 목록
	 */
	public List<Food> searchAll(FoodPageBean  bean){
		List<Food> finds = new LinkedList<Food>();
		Connection con = null;
		if(bean !=null) {
			String key = bean.getKey();
			String word = bean.getWord();
			if(!key.equals("all") && word!=null && !word.trim().equals("")) {
				if(key.equals("name")) {
					String sql = "select * from food where locate(?,name)";

					PreparedStatement pstmt = null;
					ResultSet rset = null;
					try {
						con = util.getConnection();
						pstmt = con.prepareStatement(sql);
						pstmt.setString(1, word);
						rset = pstmt.executeQuery();
						while(rset.next()) {
							Food newf = new Food(rset.getInt("code"));
							newf.setName(rset.getString("name"));
							newf.setSupportpereat(rset.getDouble("supportpereat"));
							newf.setCalory(rset.getDouble("calory"));
							newf.setCarbo(rset.getDouble("carbo"));
							newf.setProtein(rset.getDouble("protein"));
							newf.setFat(rset.getDouble("fat"));
							newf.setSugar(rset.getDouble("sugar"));
							newf.setNatrium(rset.getDouble("natrium"));
							newf.setChole(rset.getDouble("chole"));
							newf.setFattyacid(rset.getDouble("fattyacid"));
							newf.setTransfat(rset.getDouble("transfat"));
							newf.setMaker(rset.getString("maker"));
							newf.setMaterial(rset.getString("material"));
							newf.setImg(rset.getString("img"));
							finds.add(newf);
						}
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} finally {
						util.close(rset);
						util.close(pstmt);
						util.close(con);
					}
					
				} else if(key.equals("maker")) {
					String sql = "select * from food where locate(?,maker)";
					PreparedStatement pstmt = null;
					ResultSet rset = null;
					try {
						con=util.getConnection();

						pstmt = con.prepareStatement(sql);
						pstmt.setString(1, word);
						rset = pstmt.executeQuery();
						while(rset.next()) {
							Food newf = new Food(rset.getInt("code"));
							newf.setName(rset.getString("name"));
							newf.setSupportpereat(rset.getDouble("supportpereat"));
							newf.setCalory(rset.getDouble("calory"));
							newf.setCarbo(rset.getDouble("carbo"));
							newf.setProtein(rset.getDouble("protein"));
							newf.setFat(rset.getDouble("fat"));
							newf.setSugar(rset.getDouble("sugar"));
							newf.setNatrium(rset.getDouble("natrium"));
							newf.setChole(rset.getDouble("chole"));
							newf.setFattyacid(rset.getDouble("fattyacid"));
							newf.setTransfat(rset.getDouble("transfat"));
							newf.setMaker(rset.getString("maker"));
							newf.setMaterial(rset.getString("material"));
							newf.setImg(rset.getString("img"));
							finds.add(newf);
						}
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} finally {
						util.close(rset);
						util.close(pstmt);
						util.close(con);
					}
					
				} else if(key.equals("material")) {
					String sql = "select * from food where locate(?,material)";


					PreparedStatement pstmt = null;
					ResultSet rset = null;
					try {
						con=util.getConnection();
						pstmt = con.prepareStatement(sql);
						pstmt.setString(1, word);
						rset = pstmt.executeQuery();
						while(rset.next()) {
							Food newf = new Food(rset.getInt("code"));
							newf.setName(rset.getString("name"));
							newf.setSupportpereat(rset.getDouble("supportpereat"));
							newf.setCalory(rset.getDouble("calory"));
							newf.setCarbo(rset.getDouble("carbo"));
							newf.setProtein(rset.getDouble("protein"));
							newf.setFat(rset.getDouble("fat"));
							newf.setSugar(rset.getDouble("sugar"));
							newf.setNatrium(rset.getDouble("natrium"));
							newf.setChole(rset.getDouble("chole"));
							newf.setFattyacid(rset.getDouble("fattyacid"));
							newf.setTransfat(rset.getDouble("transfat"));
							newf.setMaker(rset.getString("maker"));
							newf.setMaterial(rset.getString("material"));
							newf.setImg(rset.getString("img"));
							finds.add(newf);
						}
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} finally {
						util.close(rset);
						util.close(pstmt);
						util.close(con);
					}
				}
			}else if(key.equals("all")) {
				String sql = "select * from food";
				PreparedStatement pstmt = null;
				ResultSet rset = null;
				try {
					con = util.getConnection();
					pstmt = con.prepareStatement(sql);
					rset = pstmt.executeQuery();
					while(rset.next()) {
						Food newf = new Food(rset.getInt("code"));
						newf.setName(rset.getString("name"));
						newf.setSupportpereat(rset.getDouble("supportpereat"));
						newf.setCalory(rset.getDouble("calory"));
						newf.setCarbo(rset.getDouble("carbo"));
						newf.setProtein(rset.getDouble("protein"));
						newf.setFat(rset.getDouble("fat"));
						newf.setSugar(rset.getDouble("sugar"));
						newf.setNatrium(rset.getDouble("natrium"));
						newf.setChole(rset.getDouble("chole"));
						newf.setFattyacid(rset.getDouble("fattyacid"));
						newf.setTransfat(rset.getDouble("transfat"));
						newf.setMaker(rset.getString("maker"));
						newf.setMaterial(rset.getString("material"));
						newf.setImg(rset.getString("img"));
						finds.add(newf);
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} finally {
					util.close(rset);
					util.close(pstmt);
					util.close(con);
				}
			}
		}
		return finds;
	}
	
	/**
	 * 식품 코드에 해당하는 식품정보를 검색해서 반환. 
	 * @param code	검색할 식품 코드
	 * @return	식품 코드에 해당하는 식품 정보, 없으면 null이 리턴됨
	 */
	public Food search(int code) {
		String sql = "select * from food where code = ?";
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		Food result = null;
		Connection con = null;
		
		try {
			con = util.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, code);
			rset = pstmt.executeQuery();
			if(rset.next()) {
				result = new Food(code);
				result.setName(rset.getString("name"));
				result.setSupportpereat(rset.getDouble("supportpereat"));
				result.setCalory(rset.getDouble("calory"));
				result.setCarbo(rset.getDouble("carbo"));
				result.setProtein(rset.getDouble("protein"));
				result.setFat(rset.getDouble("fat"));
				result.setSugar(rset.getDouble("sugar"));
				result.setNatrium(rset.getDouble("natrium"));
				result.setChole(rset.getDouble("chole"));
				result.setFattyacid(rset.getDouble("fattyacid"));
				result.setTransfat(rset.getDouble("transfat"));
				result.setMaker(rset.getString("maker"));
				result.setMaterial(rset.getString("material"));
				result.setImg(rset.getString("img"));
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			util.close(rset);
			util.close(pstmt);
			util.close(con);
		}
		// 코드에 맞는 식품 검색하여 리턴
		
		return result;
	}

	/**
	 * 가장 많이 검색한 Food  정보 리턴하기 
	 * web에서 구현할 내용.  
	 * @return
	 */
	public List<Food> searchBest() {
		return null;
	}
	
	public List<Food> searchBestIndex() {
		return null;
	}
	
	public static void main(String[] args) {
		FoodDaoImpl dao = new FoodDaoImpl();
		dao.loadData();
		System.out.println(dao.search(1));
		System.out.println("===========================material로 검색=================================");
		print(dao.searchAll(new FoodPageBean("material", "감자전분", null, 0)));
		System.out.println("===========================maker로 검색=================================");
		print(dao.searchAll(new FoodPageBean("maker", "빙그레", null, 0)));
		System.out.println("===========================name으로 검색=================================");
		print(dao.searchAll(new FoodPageBean("name", "라면", null, 0)));
		System.out.println("============================================================");
		print(dao.searchAll(null));
		System.out.println("============================================================");
	}
	
	public static void print(List<Food> foods) {
		for (Food food : foods) {
			System.out.println(food);
		}
	}
}
