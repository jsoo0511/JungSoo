package com.ssafy.project;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/Book")
public class BookServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");

		System.out.println("post");
		String num1 = request.getParameter("num1");
		String num2 = request.getParameter("num2");
		String num3 = request.getParameter("num3");
		String bookTitle=request.getParameter("bookTitle");
		String book_kind=request.getParameter("bookKind");
		String country=request.getParameter("country");
		String dates=request.getParameter("publish_date");
		String company=request.getParameter("company");
		String writer=request.getParameter("writer");
		String price=request.getParameter("bookPrice");
		String money=request.getParameter("money");
		String summary=request.getParameter("summary");
		System.out.println(num1+","+num2+","+book_kind+", "+dates+", "+country+", "+summary);
        
		PrintWriter out = response.getWriter();
		out.append("<html><body>"+"도서정보"+"<br><br><br>"
				+"도서명: "+bookTitle+"<br>"
				+"도서번호: "+num1+"-"+num2+"-"+num3+"<br>"
				+"도서분류: "+book_kind+"<br>"
				+"도서국가: "+country+"<br>"
				+"출판일: "+dates+"<br>"
				+"출판사: "+company+"<br>"
				+"저자: "+writer+"<br>"
				+"도서가격: "+price+money+"<br>"
				+"도서설명: "+summary+"<br></body></html>");
	}

}
