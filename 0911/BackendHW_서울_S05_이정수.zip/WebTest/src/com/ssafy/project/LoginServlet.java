package com.ssafy.project;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//import com.ssafy.project.String;

/**
 * Servlet implementation class Login
 */
@WebServlet("/Login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

  
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	System.out.println("Get");
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setCharacterEncoding("UTF-8");
		
		System.out.println("post");
		String id = request.getParameter("id");
		String pass = request.getParameter("password");
		System.out.println(id+", "+pass);
		if(id.equals("ssafy") && pass.equals("1111")){
			response.sendRedirect("Result.html");
		} else
		{
			response.sendRedirect("login.html");
		}
	}

}
