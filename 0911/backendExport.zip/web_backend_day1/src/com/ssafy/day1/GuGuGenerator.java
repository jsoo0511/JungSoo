package com.ssafy.day1;

public class GuGuGenerator {
	public String getGuGu(int dan) {
		StringBuffer sb=new StringBuffer();
		sb.append("<html><body><table border='1'><tr><th>first</th><th>second</th><th>result</th></tr>");
		for(int i=1;i<10;i++) {
			sb.append("<tr><td>"+dan+"</td><td>"+i+"</td><td>"+(dan*i)+"</td></tr>");
		}
		sb.append("</table></body></html>");
		return sb.toString();
	}

}
