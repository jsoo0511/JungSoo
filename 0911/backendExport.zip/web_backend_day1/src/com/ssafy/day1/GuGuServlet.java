package com.ssafy.day1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class GuGuServlet
 */
@WebServlet("/GuGuServlet")
public class GuGuServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		//파라미터에서 몇단을 출력할지 가져옴
		String danStr=request.getParameter("num");
		int dan=1;
		if(danStr!=null) {
			//문자열 --> 숫자변환
			dan=Integer.parseInt(danStr);
		}
			//구구단 출력(response와 printwriter 활용)
			String result=new GuGuGenerator().getGuGu(dan);
			PrintWriter out= response.getWriter();
		   out.append(result);
		
		
	}

}
