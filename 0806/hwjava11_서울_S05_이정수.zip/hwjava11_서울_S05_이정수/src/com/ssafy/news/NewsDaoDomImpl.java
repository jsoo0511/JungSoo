package com.ssafy.news;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NameList;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class NewsDaoDomImpl implements INewsDAO{
	private static List<News> list=new ArrayList<>();
	
	public NewsDaoDomImpl() {}
	
	public List<News> getNewsList(String url){
		return list;
	}
	
	protected void connectNews(String url) throws ParserConfigurationException, SAXException, IOException {
		
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factory.newDocumentBuilder();
		
		URL urls=new URL(url);
		Document doc = builder.parse(urls.openStream());
		
        Element root= doc.getDocumentElement();
		
		NodeList nodes=root.getElementsByTagName("item"); //root가 가지고 있는 모든 요소들 중 data라는 애가 있는지 검사
		
		for(int i=0;i<nodes.getLength();i++) {
			News check = new News();
			list.add(check);
			
			Node checkNode = nodes.item(i);
			
			NodeList childs = checkNode.getChildNodes();
			for(int j=0;j<childs.getLength();j++) {
				Node child = childs.item(j);
				if(child.getNodeName().equals("title")) {
					check.setTitle(child.getTextContent());
				} else if(child.getNodeName().equals("description")) {
					check.setDesc(child.getTextContent());
				} else if(child.getNodeName().equals("link")) {
					check.setLink(child.getTextContent());
				} 
			}
		}
	}

}
