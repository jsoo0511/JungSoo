package com.ssafy.news;

import java.io.IOException;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

public class NewsMain {
    public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException {
    	NewsDaoDomImpl dao=new NewsDaoDomImpl();
		dao.connectNews("http://rss.etnews.com/Section902.xml");
		List<News> news=dao.getNewsList("a");
		for(News n:news)
			System.out.println(n);
	}
}
