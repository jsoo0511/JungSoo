import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.*;

import java.sql.Connection;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.apache.ibatis.session.SqlSession;
import org.junit.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;


public class Test {

	private static Logger logger = LoggerFactory.getLogger(Test.class);
	@Autowired
    DataSource ds;

	@Autowired
	SqlSession session;

	@org.junit.Test
	public void test() throws SQLException {
		assertThat(ds,is(notNullValue()));
		Connection con=ds.getConnection();
		logger.trace("connection: {}",con);
	}
	
	@org.junit.Test
	public void SessionTest() {
		assertThat(session,is(notNullValue()));
	}

}
