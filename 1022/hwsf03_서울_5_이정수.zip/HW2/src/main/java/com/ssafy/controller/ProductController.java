package com.ssafy.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.ssafy.model.dto.Product;
import com.ssafy.model.service.ProductService;

@Controller
public class ProductController {
	
	@Autowired
	ProductService service;
	
	@GetMapping("/regist")
	public String getRegistPage() {
		return "regist";
	}
	
	@PostMapping("/regist")
	public String Regist(Product product, Model model,RedirectAttributes redir, HttpSession session) {
	    int result=service.insert(product);
	    if(result==1) {
	       redir.addFlashAttribute("message", "상품등록성공");
	       // session.setAttribute("message", "성공");
	    	//model.addAttribute("message", "성공성공");
	        return "redirect:regist";
	    }else {
	    	//redir.addFlashAttribute("message", "상품등록실패");
	    	return "regist";
	    }
		
		
	}
	
	@GetMapping("/list")
	public String List(Model model) {
		model.addAttribute("products", service.selectAll());
		return "list";
	}

}
