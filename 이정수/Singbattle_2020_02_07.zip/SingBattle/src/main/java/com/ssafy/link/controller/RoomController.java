package com.ssafy.link.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.link.dto.Room;
import com.ssafy.link.dto.Watching;
import com.ssafy.link.service.RoomServiceI;
import com.ssafy.link.service.WaitingServiceI;

import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@CrossOrigin("*")
public class RoomController {
	
	@Autowired
	RoomServiceI service;
	
	@Autowired
	WaitingServiceI wService;
	/**음악 선택시 그 음악으로 DB변경하는 것도 만들어줘야됨*/
	
	/**방 번호 찾기*/
	int arr[][]=new int[6][3];
	String name[][]=new String[6][3];
	int singer_num[]=new int[6];
	public int[] roomCheck() {
		int room_id=0;
		int user_location=0;
		int inform[]=new int[2];
		outer:for(int i=1;i<6;i++) {
			for(int j=1;j<3;j++) {
				if(arr[i][j]==0) {//i번째 방의 인원이 비어있으면
					arr[i][j]=1;
					room_id=i;
					user_location=j;
					singer_num[i]+=1;//해당 방 인원 추가
					break outer;
				}
			}
		}
		inform[0]=room_id;
		inform[1]=user_location;
		return inform;
	}
	
	/**방 나갈 사람의 위치 찾기*/
	public int[] getout(String id) {
		int []temp=new int[2];
		outer: for(int i=1;i<6;i++) {
			for(int j=1;j<3;j++) {
				if(name[i][j].equals(id)) {
					arr[i][j]=0;
					temp[0]=i;
					temp[1]=j;
					break outer;
				}
			}
		}
		return temp;
	}
	
	@GetMapping("/get_room")
	@ApiOperation("방 점보 가져오기")
	public ResponseEntity<Map<String, Object>> get_room(){
		try {
			List<Room> room=service.get_room();
			return response(room,HttpStatus.OK,true);
		} catch (Exception e) {
			e.printStackTrace();
			return response("get_room error",HttpStatus.CONFLICT,false);
		}
	}
	
	@GetMapping("/get_room_include_watching_num")
	public ResponseEntity<Map<String, Object>> get_room_w(@RequestParam int room_id){
		try {
			List<Room> room=service.get_room_include_watching_num(room_id);
			return response(room,HttpStatus.OK,true);
		} catch (Exception e) {
			e.printStackTrace();
			return response("get_room_include_watching_num 실패",HttpStatus.CONFLICT,false);
		}
	}
	
	@PutMapping("/Out_room")
	@ApiOperation("방에서 나가기, 만약 모든 player가 방에서 나갔다면 방을 폐쇄하고 시청자 를 0으로 만듦") //모든 singer가 사라지면 watcing_num도 0으로 만들어야됨.
	public ResponseEntity<Map<String, Object>> Out_room(@RequestParam String id){
		int [] room_info=getout(id);
		int room_id=room_info[0];
		try {			
			if(room_info[1]==1) {
				Room room=new Room(room_id,singer_num[room_id]-1,"1",null,null,null,0);
				service.out_room(room);
				name[room_id][room_info[1]]=null;
			} else {
				Room room=new Room(room_id,singer_num[room_id]-1,null,"1",null,null,0);
				service.out_room(room);
				name[room_id][room_info[1]]=null;
			}
			
			//만약 모든 player가 방에서 나가서 singer_num이 0이라면 방을 폐쇄하고 시청자를 0으로 만듦
			if(singer_num[room_id]-1 ==0) {
				System.out.println("방에 player가 없어요.");
				wService.set_0_watching_num(room_id);
				wService.delete_watching_in_room(room_id);
			}
			
			return response(room_id+"방에서 "+id+"가 user "+room_info[1]+"에서 방 나감",HttpStatus.OK,true);
		} catch (Exception e) {
			log.trace("Room insert error : {}", e);
			return response("방 탈출 실패",HttpStatus.CONFLICT,false);
		}
		
	}
	
	@PutMapping("/Enter_room")
	@ApiOperation("방 접속")
	public ResponseEntity<Map<String, Object>> Enter_room(@RequestParam String id){
		int room_info[]=roomCheck();
		int room_id=room_info[0];
		Map<String, Object> resultMap = new HashMap<String, Object>();
		try {
			if(room_id==0) { //풀방이면
				return response("풀방입니다.",HttpStatus.CONFLICT,false);
			} else {
				if(room_info[1]==1) {//1번 유저로 입장
					Room room=new Room(room_id,singer_num[room_id],id,null,null,null,0);
					service.udpate_room(room);
					name[room_id][room_info[1]]=id;
				}else {//2번 유저로 입장
					Room room=new Room(room_id,singer_num[room_id],null,id,null,null,0);
					service.udpate_room(room);
					name[room_id][room_info[1]]=id;
				}
				if(singer_num[room_id]==2) {
					resultMap.put("full_token"+room_id, "full");
				}
				resultMap.put("message",room_id+"방에 "+id+"가 "+singer_num[room_id]+"번째 유저로 입장");
				resultMap.put("status", HttpStatus.OK);
				return new ResponseEntity<>(resultMap,HttpStatus.OK);
			}
		} catch (Exception e) {
			log.trace("Room insert error : {}", e);
			return response("방 접속 실패",HttpStatus.CONFLICT,false);
		}
	}
	
	@GetMapping("/Get_watching")
	@ApiOperation("시청자 목록 가져오기")
	public ResponseEntity<Map<String, Object>> Get_watching(){
		try {
			List<Watching> list=service.select_watcing();
			return response(list,HttpStatus.OK,true);
		} catch (Exception e) {
			e.printStackTrace();
			return response("get watching list fail",HttpStatus.CONFLICT,false);
		}
	}
	
	@PostMapping("/Insert_watching")
	@ApiOperation("방에 시청자로 접속한 사용자들 DB에 추가") //시청자가 방에 접속시 대기실에 있던 시청자 정보 삭제
	public ResponseEntity<Map<String, Object>> Insert_watching(@RequestBody Watching watch){
		try {
			service.insert_watching(watch);
			service.plus_watching_num(watch.getRoom_id());
			wService.delete_waiting(watch.getUserid());//사용자가 방에 입장시 대기실에 있던 정보 삭제
			return response("시청자 등록 완료",HttpStatus.OK,true);
		} catch (RuntimeException e) {
			e.printStackTrace();
			return response("시청자 등록 실패",HttpStatus.CONFLICT,false);
		}
	}
	
	@PutMapping("/Update_watching")
	@ApiOperation("투표시  투표번호 변경")
	public ResponseEntity<Map<String, Object>> Update_watching(@RequestBody Watching watch){
		try {
			service.update_watching(watch);
			return response("투표 완료",HttpStatus.OK,true);
		} catch (RuntimeException e) {
			e.printStackTrace();
			return response("투표 실패",HttpStatus.CONFLICT,false);
		}
	}
	
	@DeleteMapping("/Delete_watching")
	@ApiOperation("방에서 나간 시청자들 DB에서 삭제") //방에서 나가면 대기실로 이동 -> 대기실에 명단 추가
	public ResponseEntity<Map<String, Object>> Delete_watching(@RequestBody Watching watch){
		try {
			System.out.println("대기실에서 게임방으로 시청하러 이동");
			service.delete_watching(watch.getUserid());
			service.minus_watching_num(watch.getRoom_id());
			wService.insert_waiting(watch.getUserid());//방에서 나간 사용자 대기실로 이동(추가)
			return response("시청자 방 나감",HttpStatus.OK,true);
		} catch (RuntimeException e) {
			e.printStackTrace();
			return response("시청자 방 못나감",HttpStatus.CONFLICT,false);
		}
	}
	
	private ResponseEntity<Map<String, Object>> response(Object data, HttpStatus httpStatus, boolean status) {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("data", data);
		resultMap.put("status", status);

		// 상태와 함께 Map반환
		return new ResponseEntity<>(resultMap, httpStatus);
	}
}