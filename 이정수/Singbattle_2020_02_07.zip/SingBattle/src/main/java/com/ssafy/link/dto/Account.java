package com.ssafy.link.dto;

public class Account {
	
	private String id;
	private String pw;
	public Account(String id, String pw) {
		super();
		this.id = id;
		this.pw = pw;
	}
	public Account() {
		super();
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	
	

}
