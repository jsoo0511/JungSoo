package com.ssafy.link.repository;

import java.util.List;

import com.ssafy.link.dto.Room;
import com.ssafy.link.dto.Watching;

public interface RoomRepoI {
	List<Room> get_room();
	int update_room(Room room);
	int out_room(Room room);
	int insert_watching(Watching watch);
	int delete_watching(String id);
	int update_watching(Watching watch);
	List<Watching> select_watcing();
	List<Room> get_room_include_watching_num(int room_id);
	int plus_watching_num(int room_id);
	int minus_watching_num(int room_id);
}
