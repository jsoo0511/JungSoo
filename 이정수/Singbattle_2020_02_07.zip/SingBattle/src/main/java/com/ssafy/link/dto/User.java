package com.ssafy.link.dto;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor(access=AccessLevel.PROTECTED)
@ToString
public class User {
	String userid;
	String nickname;
	String profileimg;
	String email;
	String pw;
	String provider;
	String grade;
	int game;
	int win;
	int lose;
	public User(String userid, String pw, String provider) {
		this.userid = userid;
		this.pw = pw;
		this.provider = provider;
	}
	
	
}