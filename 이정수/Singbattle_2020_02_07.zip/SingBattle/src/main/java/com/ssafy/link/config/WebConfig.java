package com.ssafy.link.config;

public class WebConfig {

}
