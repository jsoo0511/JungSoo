package com.ssafy.link.repository;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ssafy.link.dto.Account;
import com.ssafy.link.dto.User;

@Repository
public class Kakao {
	private final String namespace="com.ssafy.link.mapper.KakaoMapper.";
	
	@Autowired
	SqlSession session;
	
//
//	@Override
//	public int insertUser(User user) {
//		return this.session.insert(namespace+"insert",user);
//	}
//
//	@Override
//	public User getAll() {
//		return session.selectOne(namespace+"getAll");
//	}
}
