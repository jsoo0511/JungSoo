package com.ssafy.link.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Room_More {
	int room_id;
	int singer_num;
	String user1;
	String user2;
	String music1;
	String music2;
	int watching_num;
	String user1_grade;
	int user1_win_rate;
	String user2_grade;
	int user2_win_rate;
}
