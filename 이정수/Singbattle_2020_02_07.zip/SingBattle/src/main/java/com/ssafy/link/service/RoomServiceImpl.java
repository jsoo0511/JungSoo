package com.ssafy.link.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.link.dto.Room;
import com.ssafy.link.dto.Watching;
import com.ssafy.link.repository.RoomRepoI;

@Service
public class RoomServiceImpl implements RoomServiceI{
	
	@Autowired
	RoomRepoI repo;
	
	@Override
	public List<Room> get_room() {
		return repo.get_room();
	}
	
	@Override
	public int udpate_room(Room room) {
		return repo.update_room(room);
	}

	@Override
	public int out_room(Room room) {
		return repo.out_room(room);
	}

	@Override
	public int insert_watching(Watching watch) {
		return repo.insert_watching(watch);
	}

	@Override
	public int delete_watching(String id) {
		return repo.delete_watching(id);
	}

	@Override
	public int update_watching(Watching watch) {
		return repo.update_watching(watch);
	}

	@Override
	public List<Watching> select_watcing() {
		return repo.select_watcing();
	}

	@Override
	public List<Room> get_room_include_watching_num(int room_id) {
		return repo.get_room_include_watching_num(room_id);
	}

	@Override
	public int plus_watching_num(int room_id) {
		return repo.plus_watching_num(room_id);
	}

	@Override
	public int minus_watching_num(int room_id) {
		return repo.minus_watching_num(room_id);
	}

	

}
