package com.ssafy.project;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import day4.work.Book;
import day4.work.BookDAO;

/**
 * Servlet implementation class AddServlet
 */
@WebServlet("/addServlet")
public class AddServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String isbn=request.getParameter("num1");
		String name=request.getParameter("name");
		String maker=request.getParameter("maker");
		String author=request.getParameter("author");
		Integer price=Integer.parseInt(request.getParameter("price"));
		String summary=request.getParameter("summary");
		//모델 연동
		//Book객체 생성
		Book book =new Book(isbn, name, maker, price, summary,1);
		BookDAO dao=BookDAO.getDao();
		dao.insertBook(book);
		//마지막 등록 도서 정보 확인을 위해 쿠키 생성
		Cookie cookie=new Cookie("lastBook", book.toString());
		cookie.setMaxAge(60*60*24*7); //7일 동안만 쿠키 유지
		response.addCookie(cookie);
		
		//뷰 호출
		List<Book> books=dao.listBooks();
		request.setAttribute("books", books);
		RequestDispatcher disp=request.getRequestDispatcher("booklist.jsp");
		disp.forward(request, response);
		//response.sendRedirect("booklist.jsp");
	}

}
