package com.ssafy.product;

public class Product {
	String isbn;
	String name;
	String price;
	String explain;
	public Product(String isbn, String name, String price, String explain) {
		this.isbn = isbn;
		this.name = name;
		this.price = price;
		this.explain = explain;
	}
	@Override
	public String toString() {
		return "Product [isbn=" + isbn + ", name=" + name + ", price=" + price + ", explain=" + explain + "]";
	}
	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getExplain() {
		return explain;
	}
	public void setExplain(String explain) {
		this.explain = explain;
	}
	
	

}
