package com.ssafy.project;

import java.io.IOException;
import java.net.URLEncoder;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ssafy.product.Product;

//import day4.work.Book;
//import day4.work.BookDAO;

/**
 * Servlet implementation class AddServlet
 */
@WebServlet("/addServlet")
public class AddServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		String isbn=request.getParameter("isbn");
		String name=request.getParameter("name");
		String price=request.getParameter("price");
		String explain=request.getParameter("explain");
		System.out.println(isbn+" : "+name+" : "+price+" : "+explain);
	
	
     	Product product=new Product(isbn,name,price,explain);
		

		HttpSession session=request.getSession();
		session.setAttribute("lastproduct", product);
		//마지막 등록 상품 정보 확인을 위해 쿠키 생성
		Cookie cookie=new Cookie("recentcookie", "lastproduct");
		cookie.setMaxAge(5); //5초 동안만 쿠키 유지
		response.addCookie(cookie);

		RequestDispatcher disp=request.getRequestDispatcher("main.jsp");
		disp.forward(request, response);
	}

}
