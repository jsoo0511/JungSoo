
public class Conditioner {
	
	String isbn;
	String name;
    int price;
    int count;
    int m3;
	public Conditioner(String isbn, String name, int price, int count, int m3) {
		super();
		this.isbn = isbn;
		this.name = name;
		this.price = price;
		this.count = count;
		this.m3 = m3;
	}
	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public int getM3() {
		return m3;
	}
	public void setM3(int m3) {
		this.m3 = m3;
	}
	@Override
	public String toString() {
		return " 제품번호=" + isbn + ", 제품 이름=" + name + ", 가격=" + price + ", 수량=" + count + ", 평="
				+ m3 ;
	}
    
    

}
