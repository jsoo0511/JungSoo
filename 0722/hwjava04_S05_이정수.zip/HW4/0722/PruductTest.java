
public class PruductTest {

	public static void main(String[] args) {
	
	    TV tv=new TV("1111", "OLED", 1000000000, 111, 30, "최신형 타입");
	    Refrigerator r=new Refrigerator("2222", "Samsumg R", 10000, 111, 300);
	    Conditioner c=new Conditioner("3333", "Cool conditin", 30000, 333, 100);
	    
	    System.out.println("=============TV 정보===========");
	    System.out.println(tv.toString());
	    System.out.println("=============냉장고 정보===========");
	    System.out.println(r.toString());
	    System.out.println("=============에어컨 정보===========");
	    System.out.println(c.toString());
	    
	    

	}

}
