
public class TV {
	String isbn;
	String name;
	int price;
	int count;
	int inch;
	String type;
	public TV(String isbn, String name, int price, int count, int inch, String type) {
		super();
		this.isbn = isbn;
		this.name = name;
		this.price = price;
		this.count = count;
		this.inch = inch;
		this.type = type;
	}
	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public int getInch() {
		return inch;
	}
	public void setInch(int inch) {
		this.inch = inch;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	@Override
	public String toString() {
		return "제품번호=" + isbn + ", 제품이름=" + name + ", 가격=" + price + ", 수량=" + count + ", 인치=" + inch
				+ ", 타입=" + type;
	}
	
	

}
