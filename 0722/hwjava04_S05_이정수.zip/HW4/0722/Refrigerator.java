
public class Refrigerator {
	String isbn;
	String name;
    int price;
    int count;
    int L;
    
	public Refrigerator(String isbn, String name, int price, int count, int L) {
		super();
		this.isbn = isbn;
		this.name = name;
		this.price = price;
		this.count = count;
		this.L = L;
	}

	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public int getL() {
		return L;
	}

	public void setL(int L) {
		this.L = L;
	}

	@Override
	public String toString() {
		return "제품번호=" + isbn + ", 제품이름=" + name + ", 가격=" + price + ", 수량=" + count + ", 용량="
				+ L ;
	}
	
	

}
