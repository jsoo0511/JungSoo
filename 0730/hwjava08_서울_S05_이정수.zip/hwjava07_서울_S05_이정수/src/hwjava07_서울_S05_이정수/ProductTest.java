package hwjava07_서울_S05_이정수;

import java.util.Scanner;

public class ProductTest {

	public static void main(String[] args) {
		
		
		
		 TV tv1=new TV("1111", "OLED", 10, 11, 30);
		 TV tv2=new TV("2222","HD",99,13,51);
		 TV tv3=new TV("5555","UHD",12,36,6);
		 TV tv4=new TV("1111","asd",11,22,33);
		 Refrigerator r1=new Refrigerator("3333", "Samsumg R", 100, 11, 300);
		 Refrigerator r2=new Refrigerator("4444", "LG L", 200, 22, 200);
		 SmartPhone s1=new SmartPhone("6666", "Galaxy", 1000000, 100, "Samsung", "S10");
		 SmartPhone s2=new SmartPhone("7777", "IPhone", 2000000, 50, "Apple", "New");
		 SmartPhone s3=new SmartPhone("8888", "LPhone", 99999, 90, "Me", "GOAT");
		 Scanner sc=new Scanner(System.in);
		 Product products[]= {tv1,tv2,tv3,tv4,r1,r2,s1,s2,s3};
		 
		 ProductMgr mgr=ProductMgr.getPmgr();
		 //파일 오픈
		 mgr.open();
		 
		 //1.물건 삽입
		 for(Product product:products) {
			 try {
				 mgr.addProduct(product);
			} catch (DuplicateException e) {
	
				e.printStackTrace();
			}
			 
		 }
		 
		 //2. 전체 출력
		 System.out.println("★상품 전체 출력");
		 for(Product p:mgr.Search())
			 System.out.println(p);
		 
		 //3. isbn검색
		 try {
			 System.out.println(mgr.Byisbn("1111"));
			 System.out.println(mgr.Byisbn("1010"));
		} catch (CodeNotFoundException e) {
			e.printStackTrace();
		}
		 
		 
		 //4.상품명 검색
		 for(Product temp:mgr.ByName("L")) {
			 System.out.println(temp);
		 }
		 
		 //5.TV만 검색
		 for(Product temp:mgr.OnlyTV()) {
			 System.out.println(temp);
		 }
		 
		 //6.냉장고만 검색
		 for(Product temp:mgr.OnlyRe()) {
			 System.out.println(temp);
		 }
		 
		 //7. 400L이상 냉장고 검색
		 try {
			 for(Product temp:mgr.Over400()) {
				 System.out.println(temp);
			 }
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		 
		 //8. 50인치이상 TV검색
		 try {
			 for(Product temp:mgr.Over50()) {
				 System.out.println(temp);
			 }
		} catch (Exception e) {
			e.printStackTrace();
		}
		 
		 
		 //9. 상품번호, 가격입력받아 상품가격 변경
		 mgr.ChangePrice("1111", 20);
		 
		 //10. 상품번호로 상품 삭제
		System.out.println( mgr.Delete("5555"));
		
		 System.out.println("★제거 후 상품 목록");
		 for(Product p:mgr.Search())
			 System.out.println(p);
		 
		 //11.전체 재고상품 금액
		 System.out.println(mgr.TotalPrice());
		 
		 //12.파라미터를 전달 받아 각 제품의 재고금액 출력
		 System.out.println();
		 System.out.println("재고금액을 알고 싶은 상품을 입력하세요");
		 String kind=sc.next();
		 System.out.println("★"+kind+"의 재고금액: "+mgr.TotalPrice_Want(kind));
		 
		 //13. 파라미터를 전달 받아 각 제품의 재고 수량 출력
		 System.out.println();
		 System.out.println("재고수량을 알고 싶은 상품을 입력하세요");
		 String kind_num=sc.next();
		 System.out.println("★"+kind_num+"의 재고량: "+mgr.TotalNum_Want(kind_num));
		 
		 //14.TV재고의 평균인치계산
		 System.out.println();
		 System.out.println("★TV재고의 평균인치: "+mgr.AvgInch());
		 System.out.println();
		 
		 //15.냉장고의 리터합계
		 System.out.println("★냉장고의 리터(L)합계: "+mgr.SumL());
		 System.out.println();
		 
		 //16.스마트폰의 재고수량합계
		 System.out.println("★스마트폰의 재고수량합계: "+mgr.Sum_Remain());
		 
		 //17.
		 for(Product i:mgr.underPrice("L", 1000000))
			 System.out.println(i);
		 
		 mgr.close();
		 
	}

}
