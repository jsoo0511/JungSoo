package hwjava07_서울_S05_이정수;

public class ProductNotFoundException extends Exception{
	public ProductNotFoundException() {
		super(String.format("해당 조건을 만족하는 상품이 존재하지 않습니다."));
	}

}
