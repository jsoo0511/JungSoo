package hwjava07_서울_S05_이정수;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class ProductMgr implements IProductMgr{
	private static List<Product> products=new ArrayList<>();
	//Product[] pros = new Product[8];
    //int index=0;
    
	
    
	private static ProductMgr pd = new ProductMgr();

	public static ProductMgr getPmgr() {
		return pd;
	}

	// 상품 삽입
	public void addProduct(Product pro) throws DuplicateException{
		for(Product product:products) {
			if(product.getIsbn().equals(pro.getIsbn())) {
				throw new DuplicateException(product.getIsbn());
			}
		}
		products.add(pro);
		//return true;
	}

	@Override
	public Collection<Product> Search() {
		return products;
	}

	@Override //상품명검색
	public Product Byisbn(String isbn) throws CodeNotFoundException {
		Product search=null;
		boolean find=false;
		for(Product product:products) {
			if(product.getIsbn().equals(isbn)) {
				System.out.println();
				System.out.println("★"+isbn + "제품 찾기완료");
				search=product;
				find=true;
				break;//찾으면 탈출
			}
		}
		if(!find)
			throw new CodeNotFoundException(isbn);
		else
		    return search;
	}

	@Override
	public Collection<Product> ByName(String name) {
		List<Product>temp= new ArrayList<>();
		System.out.println();
		System.out.println("★ L포함된 상품명 검색");
		for(Product product:products) {
			if(product.getName().contains(name)) {
				temp.add(product);
			}
		}
		return temp;
	}

	@Override
	public Collection<Product> OnlyTV() {
		List<Product>temp= new ArrayList<>();
		System.out.println();
		System.out.println("★ TV검색");
		for(Product product:products) {
			if(product instanceof TV) {
				temp.add(product);
			}
		}
		return temp;
	}

	@Override
	public Collection<Product> OnlyRe() {
		List<Product>temp= new ArrayList<>();
		System.out.println();
		System.out.println("★ 냉장고검색");
		for(Product product:products) {
			if(product instanceof Refrigerator) {
				temp.add(product);
			}
		}
		return temp;
	}

	@Override //400L이상 냉장고
	public Collection<Product> Over400() throws ProductNotFoundException{
		boolean find=false;
		List<Product>temp= new ArrayList<>();
		System.out.println();
		System.out.println("★ 400L이상 냉장고검색");
		for(Product product:products) {
			if(product instanceof Refrigerator && ((Refrigerator) product).getL()>=400) {
				temp.add(product);
				find=true;
			}
		}
		if(!find)
			throw new ProductNotFoundException();
		else
		    return temp;
	}

	@Override //50inch이상 TV
	public Collection<Product> Over50() throws ProductNotFoundException{
		List<Product>temp= new ArrayList<>();
		boolean find=false;
		System.out.println();
		System.out.println("★ 50inch이상 TV검색");
		for(Product product:products) {
			if(product instanceof TV && ((TV) product).getInch()>=50) {
				temp.add(product);
				find=true;
			}
		}
		if(!find)
			throw new ProductNotFoundException();
		else
		    return temp;
	}

	@Override //상품번호, 상품가격을 입력받아 상품가격변경
	public void ChangePrice(String isbn, int nPrice) {
		System.out.println();
		System.out.println("★ 1111상품번호를 입력받아서 가격을 10에서 20으로 변경");
		for(Product product:products) {
			if(product.getIsbn().equals(isbn)) {
				System.out.println(isbn +"의 변경 전 가격: "+product.getPrice());
				product.setPrice(nPrice);
				System.out.println(isbn +"의 변경 후 가격: "+product.getPrice());
				break;
			}
		}
		
	}

	@Override
	public boolean Delete(String isbn) {
//		System.out.println();
//		System.out.println("★ 제거 전 상품목록");
//		for(int i=0;i<index;i++) {
//			System.out.println(pros[i].getIsbn());
//		}
//		System.out.println("★ 5555상품 제거");
//		for(int i=0;i<index;i++) {
//			if(pros[i].getIsbn().equals(isbn)) {
//				pros[i]=pros[index-1];
//				pros[index-1]=null;
//				index--;
//				return true;
//			}
//		}
//		return false;
		System.out.println("★ 제거 전 상품목록");
		for(Product product:products)
			System.out.println(product);
		for(int i=0;i<products.size();i++) {
			if(products.get(i).getIsbn().equals(isbn))
			{	products.remove(i);
			    return true;
			}
		}
		return false;
	}

	@Override//전체 재고상품금액
	public int TotalPrice() {
		int sum=0;
		System.out.println("★ 전체 재고금액 검색");
		for(Product product:products) {
			sum+=(product.getPrice()*product.getCount());
		}
		return sum;
	}

	@Override //선택제품별 재고금액
	public int TotalPrice_Want(String kind) {
		int sum=0;
		switch(kind) {
		case "TV":
			for(Product product:products) {
				if(product instanceof TV)
					sum+=(product.getCount()*product.getPrice());
			}
			break;
			
		case "냉장고":
			for(Product product:products) {
				if(product instanceof Refrigerator)
					sum+=(product.getCount()*product.getPrice());
			}
			break;
			
		case "SmartPhone":
			for(Product product:products) {
				if(product instanceof SmartPhone)
					sum+=(product.getCount()*product.getPrice());
			}
			break;
			
		default:
			System.out.println("없는 상품입니다.");	
		}
	return sum;
  }

	@Override //파라미터를 전달 받아 각 제품의 재고 수량 출력
	public int TotalNum_Want(String kind) {
		int sum=0;
		switch(kind) {
		case "TV":
			for(Product product:products) {
				if(product instanceof TV)
					sum+=product.getCount();
			}
			break;
			
		case "냉장고":
			for(Product product:products) {
				if(product instanceof Refrigerator)
					sum+=product.getCount();
			}
			break;
			
		case "SmartPhone":
			for(Product product:products) {
				if(product instanceof SmartPhone)
					sum+=product.getCount();
			}
			break;
			
		default:
			System.out.println("없는 상품입니다.");	
		}
	return sum;
	}

	@Override //TV재고의 평균인치계산
	public int AvgInch() {
		int avg;
		int sum=0;
		int inch=0;
		for(Product product:products) {
			if(product instanceof TV) {
				inch+=((TV) product).getInch()*product.getCount();
				sum+=product.getCount();
			}
		}
		
		avg=inch/sum;
		return avg;

	}

	@Override//냉장고의 리터(L)합계
	public int SumL() {
		int sum_L=0;
		for(Product product:products) {
			if(product instanceof Refrigerator)
				sum_L+=((Refrigerator) product).getL();
		}
		return sum_L;
		
	}

	@Override//스마트폰 재고수량 합계
	public int Sum_Remain() {
		int sum=0;
		for(Product product:products) {
			if(product instanceof SmartPhone)
				sum+=product.getCount();
		}
		return sum;
	}

	@Override//파라메터로 상품명,금액을 전달 상품명을 포함하는 상품중 전달된 금액보다 작은 금액의 상품들의 정보를 리턴
	public Collection<Product> underPrice(String name, int price) {
		List<Product> temp=new ArrayList<>();
		System.out.println("★ 100000보다 낮은 L포함된 상품명 검색");
		for(Product product:products) {
			if(product.getName().contains(name) && product.getPrice()<price)
				temp.add(product);
		}
		return temp;
	}

	@Override
	public void open() {
		try (ObjectInputStream oin = new ObjectInputStream(new FileInputStream("c:/Temp/product.dat"));){
			Object obj=oin.readObject();
			if(obj!=null)
				products=(List)obj;
			
			System.out.println("★자료 로딩 성공");
			System.out.println();
		} catch (FileNotFoundException e) {
			System.out.println("지정한 파일이 없습니다.");
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	public void close() {
		System.out.println();
		try(ObjectOutputStream oout=new ObjectOutputStream(new FileOutputStream("c:/Temp/product.dat"));) {
			oout.writeObject(products);
			System.out.println("★파일 저장 완료");
		} catch (FileNotFoundException e) {
			System.out.println("★지정한 파일이 없습니다.");
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	

}
