package hwjava07_서울_S05_이정수;

public class TV extends Product{
	
	int inch;
	
	public TV(String isbn, String name, int price, int count,int inch) {
		super(isbn,name,price,count);
		this.inch = inch;
		
	}
	public int getInch() {
		return inch;
	}
	public void setInch(int inch) {
		this.inch = inch;
	}
	
	@Override
	public String toString() {
		return super.toString()+" 인치= " + inch;
	}
	
	
}