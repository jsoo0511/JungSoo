package com.ssafy.todo.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class ApplicationConfig {

}
