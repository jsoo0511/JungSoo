package com.ssafy.day2.model;

public class CalcService {
	public int calc(int a,int b) {
		return a+b;
	}

}
