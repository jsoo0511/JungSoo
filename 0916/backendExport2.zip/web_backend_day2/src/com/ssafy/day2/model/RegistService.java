package com.ssafy.day2.model;

import java.util.Arrays;

public class RegistService {
	
	
	public boolean regist(String name, String id, String pass,String []alergy) {
		//DAO와 연동해서 DB에 insert처리
		System.out.println(name+" : "+id+" : "+pass+" : "+Arrays.toString(alergy));
		return !id.equals("admin");
	}

}
