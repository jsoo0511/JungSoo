<template>
    <div>
        <h1>사원목록</h1>

        <table border="1" class="list_table">
            <tr>
                <th>사원 아이디</th>
                <th>사원명</th>
                <th>부서</th>
                <th>직책</th>
                <th>연봉</th>
                <th>퇴사</th>
            </tr>

            <tr v-for="emp of emps" :key="emp.id" @click="detail(emp.id)">
                <td>{{emp.id}}</td>
                <td>{{emp.name}}</td>
                <td>{{emp.dept_id}}</td>
                <td>{{emp.title}}</td>
                <td>{{emp.salary}}</td>
                <td><input type="button" value="퇴사"></td>
            </tr>
        </table>
    </div>
</template>

<script>
import axios from "axios";
import router from "../assets/router.js"

export default {
    data() {
        return {
            emps: []
        }
    },

    mounted() {
        axios
        .get("http://localhost:8197/ssafyvue/api/findAllEmployees")
        .then(res => {
            this.emps = res.data;
        })
        .catch(e => {
            console.log(e);
        })
        .finally(() => {

        })
    },

    methods: {
        detail(id) {
            router.push({
                path: "/detail/"+id
            })
        }
    },
}
</script>

<style>

</style>

<style scoped>
    #mytable {
        margin: 0 auto;
    }

    #mycolor {
        background-color: royalblue;
        color: white;
    }
</style>