<template>
    <div>
        <h1>세부정보</h1>

        <table border="1" class="list_table">
            <tr>
                <th>사원 아이디</th>
                <th>사원명</th>
                <th>부서</th>
                <th>직책</th>
                <th>연봉</th>
            </tr>

            <tr>
                <td disabled>{{emp.id}}</td>
                <td>{{emp.name}}</td>
                <td>{{emp.dept_id}}</td>
                <td>{{emp.title}}</td>
                <td>{{emp.salary}}</td>
            </tr>
        </table>
    </div>
</template>

<script>
import axios from "axios";

export default {
    props: ["id"],
    data() {
        return {
            emp: {}
        }
    },

    mounted() {
        axios
        .get("http://localhost:8197/ssafyvue/api/findEmployeeById/" + this.id)
        .then(res => {
            this.emp = res.data;
        })
        .catch(e => {
            console.log(e);
        })
        .finally(() => {

        })
    },
}
</script>

<style>

</style>

<style scoped>
    #mytable {
        margin: 0 auto;
    }

    #mycolor {
        background-color: royalblue;
        color: white;
    }
</style>