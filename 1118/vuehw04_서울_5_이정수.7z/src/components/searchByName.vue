<template>
    <div>
        <h1>이름으로 찾기</h1>
        <input type="text" id="searchname" placeholder="이름을 입력해주세요" v-model="searchname">
        <input type="button" value="찾기" @click="searchById()">

        <table border="1" class="list_table2">
            <tr class="list_table">
                <th>사원 아이디</th>
                <th>사원명</th>
                <th>부서</th>
                <th>직책</th>
                <th>연봉</th>
            </tr>

            <tr v-for="emp of emps" :key="emp.id">
                <td>{{emp.id}}</td>
                <td>{{emp.name}}</td>
                <td>{{emp.dept_id}}</td>
                <td>{{emp.title}}</td>
                <td>{{emp.salary}}</td>
            </tr>
        </table>
    </div>
</template>

<script>
import axios from "axios";

export default {
    data() {
        return {
            searchname: "",
            emps: []
        }
    },

    methods: {
        searchById() {
            axios
            .get("http://localhost:8197/ssafyvue/api/findLikeEmployees/" + this.searchname)
            .then(res => {
                this.emps = res.data;
            })
            .catch(e => {
                console.log(e);
            })
            .finally(() => {

            })
        }
    },
}
</script>

<style>

</style>

<style scoped>
    #mytable {
        margin: 0 auto;
    }

    #mycolor {
        background-color: royalblue;
        color: white;
    }
</style>