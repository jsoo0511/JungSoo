import VueRouter from 'vue-router'
import emplist from "../components/emplist.vue"
import detail from "../components/detail.vue"
import searchByName from "../components/searchByName.vue"

const router = new VueRouter({
    routes: [
        {
            name:"emplist",
            path:"/emplist",
            component:emplist
        },

        {
            name:"detail",
            path:"/detail/:id",
            props:true,
            component:detail
        },

        {
            name:"searchByName",
            path:"/searchByName",
            component:searchByName
        }
    ]
})

export default router;