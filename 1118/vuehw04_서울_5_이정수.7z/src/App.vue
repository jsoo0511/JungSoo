<template>
  <div id="app">
    <router-link to="/emplist">모든목록</router-link>/
    <router-link to="/searchByName">이름으로 찾기</router-link>

    <router-view></router-view>
  </div>
</template>

<script>
import router from "./assets/router.js"
export default {
  name: 'app',
  router,
  components: {
    
  }
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
