package com.ssafy.pms.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.pms.Phone;
import com.ssafy.pms.repo.service.IPhoneService;

import io.swagger.annotations.ApiOperation;

@RestController  //응답: json으로 갈거다
@RequestMapping("/pms/rest")
@CrossOrigin(value="*")
public class PhoneRestController {
	
	Map<String, Phone> phones = new HashMap<>();
	private static Logger logger = LoggerFactory.getLogger(PhoneRestController.class);
	
	@Autowired
	IPhoneService service;
	
	@PostMapping("/phone")
	public ResponseEntity<Map<String,Object>> insert(@RequestBody Phone phone){ //파라미터가 json으로 올것이다.
		
		try {
			int result=service.insertRest(phone);
			return response(result, HttpStatus.CREATED,true);
		} catch (RuntimeException e) {
			logger.error("추가 실패",e);
			return response(e.getMessage(),HttpStatus.CONFLICT,false);
			
		}	
	}
	
	@GetMapping("/phone")
	@ApiOperation("전체검색")
	public ResponseEntity<Map<String, Object>> selectAll() {
		try {
			List<Phone> phones=service.selectRestAll();
			return response(phones,HttpStatus.CREATED,true);
		} catch (RuntimeException e) {
			return response(e.getMessage(),HttpStatus.CONFLICT,false);
		}
	}
	
	@PutMapping("/phone")
	@ApiOperation("할일 수정")
	public ResponseEntity<Map<String, Object>> modify2(@RequestBody Phone phone) {
		logger.trace("modify2: {}", phone);
		try {
			int update=service.updateRest(phone);
			return response(update,HttpStatus.CREATED,true);
		} catch (RuntimeException e) {
			return response(e.getMessage(),HttpStatus.CONFLICT,false);
		}
	}
	
	@GetMapping("/phone/{num}")
	public ResponseEntity<Map<String, Object>> select(@PathVariable String num) {
		try {
			Phone phone=service.selectRest(num);
			return response(phone,HttpStatus.CREATED,true);
		} catch (RuntimeException e) {
			return response(e.getMessage(),HttpStatus.CONFLICT,false);
		}
	}
	
	@DeleteMapping("/phone/{num}")
	public ResponseEntity<Map<String, Object>> delete(@PathVariable String num){
		try {
			int delete=service.deleteRest(num);
			return response(delete,HttpStatus.CREATED,true);
		} catch (RuntimeException e) {
			return response(e.getMessage(),HttpStatus.CONFLICT,false);
		}
	}
	
	private ResponseEntity<Map<String, Object>> response(Object data, HttpStatus httpStatus, boolean status){
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("data",data);
		resultMap.put("status",status);
		
		
		//상태와 함께 Map반환
		return new ResponseEntity<>(resultMap,httpStatus);
	}

}
