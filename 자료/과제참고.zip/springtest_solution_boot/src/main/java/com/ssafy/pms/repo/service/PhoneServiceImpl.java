package com.ssafy.pms.repo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ssafy.pms.Phone;
import com.ssafy.pms.Userinfo;
import com.ssafy.pms.repo.IPhoneDAO;

@Service
public class PhoneServiceImpl implements IPhoneService{
	
	@Autowired
    IPhoneDAO repo;

	@Override
	public Userinfo selectUser(Userinfo user) {
		return repo.selectUser(user);
	}

	@Override
	@Transactional
	public int insert(Phone phone) {
		return repo.insert(phone);
	}

	@Override
	public List<Phone> select() {
		// TODO Auto-generated method stub
		return repo.select();
	}

	@Override
	public Phone select(Phone phone) {
		// TODO Auto-generated method stub
		return repo.select(phone);
	}

	@Override
	@Transactional
	public int delete(List<String> list) {
		return repo.delete(list);
	}

	@Override
	public int insertRest(Phone phone) {
		return repo.insertRest(phone);
	}

	@Override
	public int updateRest(Phone phone) {
		// TODO Auto-generated method stub
		return repo.updateRest(phone);
	}

	@Override
	public int deleteRest(String num) {
		// TODO Auto-generated method stub
		return repo.deleteRest(num);
	}

	@Override
	public Phone selectRest(String num) {
		// TODO Auto-generated method stub
		return repo.selectRest(num);
	}

	@Override
	public List<Phone> selectRestAll() {
		// TODO Auto-generated method stub
		return repo.selectRestAll();
	}

}
