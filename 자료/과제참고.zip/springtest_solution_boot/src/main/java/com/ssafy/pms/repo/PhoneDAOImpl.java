package com.ssafy.pms.repo;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ssafy.pms.Phone;
import com.ssafy.pms.Userinfo;

@Repository
public class PhoneDAOImpl implements IPhoneDAO{

	private final String ns="sql.pms.";
	
	@Autowired
	SqlSession session;
	
	
	@Override
	public Userinfo selectUser(Userinfo user) {
		return session.selectOne(ns+"selectUser", user);
	}


	@Override
	public int insert(Phone phone) {
		return session.insert(ns+"insert",phone);
	}


	@Override
	public List<Phone> select() {
		return session.selectList(ns+"select",null);
	}


	@Override
	public Phone select(Phone phone) {
		return session.selectOne(ns+"select",phone);
	}


	@Override
	public int delete(List<String> list) {
		return session.delete(ns+"delete",list);
	}


	@Override
	public int insertRest(Phone phone) {
		return session.insert(ns+"restInsert",phone);
	}


	@Override
	public int updateRest(Phone phone) {
		// TODO Auto-generated method stub
		return session.update(ns+"restUpdate",phone);
	}


	@Override
	public int deleteRest(String num) {
		return session.delete(ns+"restDelete",num);
	}


	@Override
	public Phone selectRest(String num) {
		// TODO Auto-generated method stub
		return session.selectOne(ns+"restSelect",num);
	}


	@Override
	public List<Phone> selectRestAll() {
		// TODO Auto-generated method stub
		return session.selectList(ns+"restSelect");
	}
	
	

}
