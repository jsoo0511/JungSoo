package com.example.pms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringtestSolutionBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
