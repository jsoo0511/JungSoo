package com.ssafy.safefood;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SafefoodDaeheeApplication {

	public static void main(String[] args) {
		SpringApplication.run(SafefoodDaeheeApplication.class, args);
	}

}
