package com.ssafy.safefood.service;

import java.util.List;

import com.ssafy.safefood.dto.Board;
import com.ssafy.safefood.dto.PageBean;

public interface BoardService {
	
	// 게시글 추가
	public int insertBoard(Board board);

	// 게시글 업데이트
	public int updateBoard(Board board);

	// 게시글 삭제
	public int deleteBoard(String no);

	// 해당 글
	public Board search(String no);

	// 조건에 맞는 글 모두 검색
	public List<Board> searchAll(PageBean bean);
}
