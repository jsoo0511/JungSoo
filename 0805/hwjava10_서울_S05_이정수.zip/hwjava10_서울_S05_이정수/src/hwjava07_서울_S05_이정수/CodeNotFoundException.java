package hwjava07_서울_S05_이정수;

public class CodeNotFoundException extends Exception{
	public CodeNotFoundException(String isbn) {
		super(String.format("%s는 없는 상품", isbn));
	}

}
