package hwjava07_서울_S05_이정수;

import java.io.Serializable;

public class Product implements Serializable{
	String isbn;
	String name;
	int price;
	int count;
	
	public Product() {}
	
	public Product(String isbn, String name, int price, int count) {
		super();
		this.isbn = isbn;
		this.name = name;
		this.price = price;
		this.count = count;
	}
	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public String getName() {
		return name;
	}

	@Override
	public String toString() {
		return "제품번호=" + isbn + " 제품이름=" + name + " 가격=" + price + " 재고=" + count + " ";
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	

}
