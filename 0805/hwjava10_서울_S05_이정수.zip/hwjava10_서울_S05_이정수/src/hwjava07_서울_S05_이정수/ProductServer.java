package hwjava07_서울_S05_이정수;

import java.io.BufferedWriter;
import java.io.ObjectInputStream;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.List;
import java.util.Map;



public class ProductServer {
	public static void main(String[] args) {
		try (
				ServerSocket ss= new ServerSocket(9999)
				) {
			
			System.out.println("server is ready...");
			while(true) {
				try(Socket socket = ss.accept();
						ObjectInputStream oin = new ObjectInputStream(socket.getInputStream());
						BufferedWriter br = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));) {
					Object obj=oin.readObject();
					if(obj!=null) {
						System.out.println("객체 수신: "+obj);
						if(obj instanceof List) { //not null이고 list라면
							List<Product> list = (List)obj;
							br.write(list.size()+"");
						} //else if(obj instanceof Map) {
						//	Map<String,Book> map=(Map)obj;
						//	br.write(map.size()+"");
					//	}
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

}
