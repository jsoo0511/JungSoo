package hwjava07_서울_S05_이정수;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class ProductClient extends Thread{
     Object products;
	
	int size; //몇개인지
    public ProductClient(Object products, int size) {
		this.products=products;
		this.size=size;
	}
    @Override
    public void run() {
        try (Socket socket = new Socket("localhost", 9999);
                ObjectOutputStream socketOut = new ObjectOutputStream(socket.getOutputStream());
                BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {
                List<Product> temp = new ArrayList<>();
            if (products instanceof List) {
                List<Product> ps = (List) products;
                for (int i = 0; i < ((List) products).size(); i++) {
                    if (ps.get(i) instanceof TV) {
                        temp.add(ps.get(i));
                    }
                }
                for (int i = 0; i < ((List) products).size(); i++) {
                    if (!(ps.get(i) instanceof TV)) {
                        temp.add(ps.get(i));
                    }
                }
            }
            socketOut.writeObject(temp);
            String readed = br.readLine();
            if (size == Integer.parseInt(readed)) {
                System.out.println("전송한 데이터의 개수는 "+size+"개 입니다.");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
