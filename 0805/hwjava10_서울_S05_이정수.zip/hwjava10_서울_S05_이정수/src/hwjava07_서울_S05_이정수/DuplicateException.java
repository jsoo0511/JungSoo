package hwjava07_서울_S05_이정수;

public class DuplicateException extends Exception{
	public DuplicateException(String isbn) {
		super(String.format("%s는 이미 있는 상품", isbn));
	}

}
