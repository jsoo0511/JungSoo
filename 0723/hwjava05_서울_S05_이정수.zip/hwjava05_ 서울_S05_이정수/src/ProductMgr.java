

public class ProductMgr {
	Product[] pros = new Product[5];

	private static ProductMgr pd = new ProductMgr();

	public static ProductMgr getPmgr() {
		return pd;
	}

	// 상품 삽입
	public boolean addProduct(Product pro) {

		for (int i = 0; i < pros.length; i++) {
			Product stored = pros[i];
			if (stored == null) {
				pros[i] = pro;
				return true;
			}
		}
		return false;
	}

	// 3. isbn검색
	public Product Byisbn(String isbn) {
		System.out.println();
		Product look = null;
		for (Product temp : pros) {
			if (temp.getIsbn().equals(isbn)) {
				System.out.println("★"+isbn + "제품 찾기완료");
				look = temp;
				break;
			}
		}
		return look;
	}

	// 4. 상품명 검색
	public Product[] ByName(String name) {
		Product[] temp = new Product[5];
		int idx = 0;
		System.out.println();
		System.out.println("★ L포함된 상품명 검색");
		for (int i = 0; i < 5; i++) {
			if (pros[i].getName().contains(name)) {
				temp[idx++] = pros[i];
			}
		}
		Product[] temp2 = new Product[idx];
		System.arraycopy(temp, 0, temp2, 0, temp2.length);
		return temp2;
	}

	// 5.TV정보만 검색
	public Product[] OnlyTV() {
		System.out.println();
		System.out.println("★ TV검색");
		Product temp[]=new Product[5];
		int idx=0;
		for(int i=0;i<pros.length;i++) {
		  if(pros[i] instanceof TV) {
			temp[idx++]=pros[i];
		 }
		}
		Product[] temp2 = new Product[idx];
		System.arraycopy(temp, 0, temp2, 0, temp2.length);
		return temp2;
	}
	
	//6. Refrigerator만 검색
	public Product[] OnlyRe() {
		System.out.println();
		System.out.println("★ 냉장고검색");
		Product temp[]=new Product[5];
		int idx=0;
		for(int i=0;i<pros.length;i++) {
		  if(pros[i] instanceof Refrigerator) {
			temp[idx++]=pros[i];
		 }
		}
		Product[] temp2 = new Product[idx];
		System.arraycopy(temp, 0, temp2, 0, temp2.length);
		return temp2;
	}
	
	//7. 400L이상 냉장고 검색
	public Product[] Over400() {
		System.out.println();
		System.out.println("★ 400L이상 냉장고검색");
		Product temp[]=new Product[5];
		
		Refrigerator k;
		int idx=0;
		for(int i=0;i<pros.length;i++) {
		  if(pros[i] instanceof Refrigerator) {
			k=(Refrigerator)pros[i];
			if(k.getL()>=400)
			    temp[idx++]=pros[i];
		 }
		}
		Product[] temp2 = new Product[idx];
		System.arraycopy(temp, 0, temp2, 0, temp2.length);
		return temp2;
	}
	
	//8. 50inch이상 TV검색
	public Product[] Over50() {
		System.out.println();
		System.out.println("★ 50inch이상 냉장고검색");
		Product temp[]=new Product[5];
		
		TV k;
		int idx=0;
		for(int i=0;i<pros.length;i++) {
		  if(pros[i] instanceof TV) {
			k=(TV)pros[i];
			if(k.getInch()>=50)
			    temp[idx++]=pros[i];
		 }
		}
		Product[] temp2 = new Product[idx];
		System.arraycopy(temp, 0, temp2, 0, temp2.length);
		return temp2;
	}
	
	//9.상품번호, 상품가격을 입력받아 상품가격변경
	public void ChangePrice(String isbn, int nPrice) {
		System.out.println();
		System.out.println("★ 1111상품번호를 입력받아서 가격을 10에서 20으로 변경");
		Product look = null;
		for (Product temp : pros) {
			if (temp.getIsbn().equals(isbn)) {
				System.out.println(isbn +"의 변경 전 가격: "+temp.getPrice());
				temp.setPrice(nPrice);
				System.out.println(isbn +"의 변경 후 가격: "+temp.getPrice());
				break;
			}
		}
	}
	
	//10.상품번호로 상품 삭제
	public void Delete(String isbn) {
		System.out.println();
		System.out.println("★ 제거 전 상품목록");
		for(int i=0;i<pros.length;i++) {
			System.out.println(pros[i].getIsbn());
		}
		System.out.println("★ 5555상품 제거");
		for(int i=0;i<pros.length;i++) {
			if(pros[i].getIsbn().equals(isbn)) {
				for(int j=i;j<pros.length-1;j++) {
					pros[j]=pros[j+1];
				}
				break;
			}
		}
		System.out.println("★ 제거 후 상품목록");
		for(int i=0;i<pros.length-1;i++) {
			System.out.println(pros[i].getIsbn());
		}
		
		
	}
	
	//11.전체 재고상품금액
	public int TotalPrice() {
		System.out.println();
		System.out.println("★ 전체 재고금액 검색");
		int result=0;
		for(int i=0;i<pros.length;i++) {
			if(pros[i]==null)
				continue;
			result+=pros[i].getCount()*pros[i].getPrice();
		}
		return result;
	}
	

}
