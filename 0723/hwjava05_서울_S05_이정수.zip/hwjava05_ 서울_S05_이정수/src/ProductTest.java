

public class ProductTest {

	public static void main(String[] args) {
		 TV tv1=new TV("1111", "OLED", 10, 11, 30, "최신형 타입");
		 TV tv2=new TV("2222","HD",99,13,51,"구식 타입");
		 TV tv3=new TV("5555","UHD",12,36,56,"중간 버전");
		 Refrigerator r1=new Refrigerator("3333", "Samsumg R", 100, 11, 300);
		 Refrigerator r2=new Refrigerator("4444", "LG L", 200, 22, 500);
		 
		 Product products[]= {tv1,tv2,tv3,r1,r2};
		 
		 ProductMgr mgr=ProductMgr.getPmgr();
		 
		 
		 //1.물건 삽입
		 for(Product product:products)
			 mgr.addProduct(product);
		 
		 //2. 전체 출력
		 System.out.println("★상품 전체 출력");
		 for(Product p:products)
			 System.out.println(p.toString());
		 
		 //3. isbn검색
		 System.out.println(mgr.Byisbn("1111"));
		 
		 //4.상품명 검색
		 for(Product temp:mgr.ByName("L")) {
			 System.out.println(temp);
		 }
		 
		 //5.TV만 검색
		 for(Product temp:mgr.OnlyTV()) {
			 System.out.println(temp);
		 }
		 
		 //6.냉장고만 검색
		 for(Product temp:mgr.OnlyRe()) {
			 System.out.println(temp);
		 }
		 
		 //7. 400L이상 냉장고 검색
		 for(Product temp:mgr.Over400()) {
			 System.out.println(temp);
		 }
		 
		 //8. 50인치이상 TV검색
		 for(Product temp:mgr.Over50()) {
			 System.out.println(temp);
		 }
		 
		 //9. 상품번호, 가격입력받아 상품가격 변경
		 mgr.ChangePrice("1111", 20);
		 
		 //10. 상품번호로 상품 삭제
		 mgr.Delete("5555");
		
		 
		 //11.전체 재고상품 금액
		 System.out.println(mgr.TotalPrice());
	}

}
