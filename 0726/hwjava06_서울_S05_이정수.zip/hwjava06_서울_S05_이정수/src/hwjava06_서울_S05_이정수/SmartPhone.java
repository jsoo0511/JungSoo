package hwjava06_서울_S05_이정수;

public class SmartPhone extends Product{
	String vendor;
	String model;
	
	
	public SmartPhone(String isbn, String name, int price, int count,String vendor, String model) {
		super(isbn,name,price,count);
		this.vendor = vendor;
		this.model = model;
	}
	public String getVendor() {
		return vendor;
	}
	public void setVendor(String vendor) {
		this.vendor = vendor;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	@Override
	public String toString() {
		return super.toString()+" 벤더=" + vendor + "  모델명= "+model;
	}
	

}
