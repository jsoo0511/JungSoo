package hwjava06_서울_S05_이정수;



public class ProductMgr {
	Product[] pros = new Product[8];
    int index=0;
	private static ProductMgr pd = new ProductMgr();

	public static ProductMgr getPmgr() {
		return pd;
	}

	// 상품 삽입
	public boolean addProduct(Product pro) {
		
		if(index>=pros.length) {
			System.out.println("배열 초과");
			return false;
		}
		else {
			pros[index++]=pro;
			return true;
		}

		/*for (int i = 0; i < pros.length; i++) {
			Product stored = pros[i];
			if (stored == null) {
				pros[i] = pro;
				return true;
			}
		}
		return false;*/
	}
	
	public Product[] Search() {
		Product temp[]=new Product[index];
		for(int i=0;i<index;i++) {
			Product product=pros[i];
			if(product !=null)
				temp[i]=product;
		}
		return temp;
	}

	// 3. isbn검색
	public Product Byisbn(String isbn) {
		System.out.println();
		Product look = null;
		for (Product temp : pros) {
			if (temp.getIsbn().equals(isbn)) {
				System.out.println("★"+isbn + "제품 찾기완료");
				look = temp;
				break;
			}
		}
		return look;
	}

	// 4. 상품명 검색
	public Product[] ByName(String name) {
		Product[] temp = new Product[8];
		int idx = 0;
		System.out.println();
		System.out.println("★ L포함된 상품명 검색");
		for (int i = 0; i < index; i++) {
			if (pros[i].getName().contains(name)) {
				temp[idx++] = pros[i];
			}
		}
		Product[] temp2 = new Product[idx];
		System.arraycopy(temp, 0, temp2, 0, temp2.length);
		return temp2;
	}

	// 5.TV정보만 검색
	public Product[] OnlyTV() {
		System.out.println();
		System.out.println("★ TV검색");
		Product temp[]=new Product[8];
		int idx=0;
		for(int i=0;i<pros.length;i++) {
		  if(pros[i] instanceof TV) {
			temp[idx++]=pros[i];
		 }
		}
		Product[] temp2 = new Product[idx];
		System.arraycopy(temp, 0, temp2, 0, temp2.length);
		return temp2;
	}
	
	//6. Refrigerator만 검색
	public Product[] OnlyRe() {
		System.out.println();
		System.out.println("★ 냉장고검색");
		Product temp[]=new Product[8];
		int idx=0;
		for(int i=0;i<pros.length;i++) {
		  if(pros[i] instanceof Refrigerator) {
			temp[idx++]=pros[i];
		 }
		}
		Product[] temp2 = new Product[idx];
		System.arraycopy(temp, 0, temp2, 0, temp2.length);
		return temp2;
	}
	
	//7. 400L이상 냉장고 검색
	public Product[] Over400() {
		System.out.println();
		System.out.println("★ 400L이상 냉장고검색");
		Product temp[]=new Product[8];
		
		Refrigerator k;
		int idx=0;
		for(int i=0;i<pros.length;i++) {
		  if(pros[i] instanceof Refrigerator) {
			k=(Refrigerator)pros[i];
			if(k.getL()>=400)
			    temp[idx++]=pros[i];
		 }
		}
		Product[] temp2 = new Product[idx];
		System.arraycopy(temp, 0, temp2, 0, temp2.length);
		return temp2;
	}
	
	//8. 50inch이상 TV검색
	public Product[] Over50() {
		System.out.println();
		System.out.println("★ 50inch이상 냉장고검색");
		Product temp[]=new Product[5];
		
		TV k;
		int idx=0;
		for(int i=0;i<pros.length;i++) {
		  if(pros[i] instanceof TV) {
			k=(TV)pros[i];
			if(k.getInch()>=50)
			    temp[idx++]=pros[i];
		 }
		}
		Product[] temp2 = new Product[idx];
		System.arraycopy(temp, 0, temp2, 0, temp2.length);
		return temp2;
	}
	
	//9.상품번호, 상품가격을 입력받아 상품가격변경
	public void ChangePrice(String isbn, int nPrice) {
		System.out.println();
		System.out.println("★ 1111상품번호를 입력받아서 가격을 10에서 20으로 변경");
		Product look = null;
		for (Product temp : pros) {
			if (temp.getIsbn().equals(isbn)) {
				System.out.println(isbn +"의 변경 전 가격: "+temp.getPrice());
				temp.setPrice(nPrice);
				System.out.println(isbn +"의 변경 후 가격: "+temp.getPrice());
				break;
			}
		}
	}
	
	//10.상품번호로 상품 삭제
	public boolean Delete(String isbn) {
		System.out.println();
		System.out.println("★ 제거 전 상품목록");
		for(int i=0;i<index;i++) {
			System.out.println(pros[i].getIsbn());
		}
		System.out.println("★ 5555상품 제거");
		for(int i=0;i<index;i++) {
			if(pros[i].getIsbn().equals(isbn)) {
				pros[i]=pros[index-1];
				pros[index-1]=null;
				index--;
				return true;
			}
		}
		return false;
		
	}
	
	//11.전체 재고상품금액
	public int TotalPrice() {
		System.out.println();
		System.out.println("★ 전체 재고금액 검색");
		int result=0;
		for(int i=0;i<index;i++) {
			if(pros[i]==null)
				continue;
			result+=pros[i].getCount()*pros[i].getPrice();
		}
		return result;
	}
	
	//12.선택제품별 재고금액
	public int TotalPrice_Want(String kind) {
		int sum=0;
		switch(kind) {
		case "TV":
			for(int i=0;i<index;i++) {
				if(pros[i]==null)
					continue;
				if(pros[i] instanceof TV) {
					TV k=(TV)pros[i];
					sum+=(k.getCount()*k.getPrice()); //TV 제품 재고합계
				}
			}
			break;
		case "냉장고":
			for(int i=0;i<index;i++) {
				if(pros[i]==null)
					continue;
				if(pros[i] instanceof Refrigerator) {
					Refrigerator k=(Refrigerator)pros[i];
					sum+=(k.getCount()*k.getPrice()); //냉장고 제품 재고합계
				}
			}
			break;
			
		case "SmartPhone":
			for(int i=0;i<index;i++) {
				if(pros[i]==null)
					continue;
				if(pros[i] instanceof SmartPhone) {
					SmartPhone k=(SmartPhone)pros[i];
					sum+=(k.getCount()*k.getPrice()); //스마트폰 제품 재고합계
				}
			}
			break;
			
			default:
				System.out.println("없는 상품입니다.");
		}
		return sum;
	}
	
	//13. 파라미터를 전달 받아 각 제품의 재고 수량 출력
	public int TotalNum_Want(String kind) {
		int sum=0;
		switch(kind) {
		case "TV":
			for(int i=0;i<index;i++) {
				if(pros[i]==null)
					continue;
				if(pros[i] instanceof TV) {
					TV k=(TV)pros[i];
					sum+=k.getCount(); //TV 제품 재고합계
				}
			}
			break;
		case "냉장고":
			for(int i=0;i<index;i++) {
				if(pros[i]==null)
					continue;
				if(pros[i] instanceof Refrigerator) {
					Refrigerator k=(Refrigerator)pros[i];
					sum+=k.getCount(); //냉장고 제품 재고합계
				}
			}
			break;
			
		case "SmartPhone":
			for(int i=0;i<index;i++) {
				if(pros[i]==null)
					continue;
				if(pros[i] instanceof SmartPhone) {
					SmartPhone k=(SmartPhone)pros[i];
					sum+=k.getCount(); //스마트폰 제품 재고합계
				}
			}
			break;
			
			default:
				System.out.println("없는 상품입니다.");
		}
		return sum;
	}
	
	//TV재고의 평균인치계산
	public int AvgInch() {
		int sum=0;
		int inchs=0;
		int avg=0;
		for(int i=0;i<index;i++) {
			if(pros[i]==null)
				continue;
			if(pros[i] instanceof TV) {
				TV k=(TV)pros[i];
				inchs+=(k.getInch()*k.getCount());
				sum+=k.getCount(); //TV 제품 재고합계
			}
		}
		avg=inchs/sum;
		return avg;
	}
	
	//냉장고의 리터(L)합계
	public int SumL() {
		int sum=0;
		for(int i=0;i<index;i++) {
			if(pros[i]==null)
				continue;
			if(pros[i] instanceof Refrigerator) {
				Refrigerator k=(Refrigerator)pros[i];
				sum+=k.getL(); //냉장고 제품 재고합계
			}
		}
		return sum;
	}
	
	//스마트폰 재고수량 합계
	public int Sum_Remain() {
		int sum=0;
		for(int i=0;i<index;i++) {
			if(pros[i]==null)
				continue;
			if(pros[i] instanceof SmartPhone) {
				SmartPhone k=(SmartPhone)pros[i];
				sum+=k.getCount(); //냉장고 제품 재고합계
			}
		}
		return sum;
	}
	
	//파라메터로 상품명,금액을 전달 상품명을 포함하는 상품중 전달된 금액보다 작은 금액의 상품들의 정보를 리턴
	public Product[] underPrice(String name, int price) {
		Product[] temp = new Product[index]; 
		int idx = 0;
		System.out.println();
		System.out.println("★ 100000보다 낮은 L포함된 상품명 검색");
		for (int i = 0; i < index; i++) {
			if (pros[i].getName().contains(name) && pros[i].getPrice()<price) { //상품명 포함된 애들 검색해서 새로 배열에 추가
				temp[idx++] = pros[i];
			}
		}
		Product[] temp2 = new Product[idx];
		System.arraycopy(temp, 0, temp2, 0, temp2.length); //배열에 카피카피
		return temp2;
	}
	
	
	

}
