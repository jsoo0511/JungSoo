package com.ssafy.board.Repository;

import java.util.List;

import com.ssafy.board.Board;

public interface Repository {
	int insert(Board board);
	List<Board> selectAll();

}
