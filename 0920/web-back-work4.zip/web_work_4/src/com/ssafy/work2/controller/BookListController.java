package com.ssafy.work2.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import day4.work.Book;
import day4.work.BookDAO;

public class BookListController implements Controller {

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 뷰 호출
		BookDAO dao = BookDAO.getDao();
		List<Book> books = dao.listBooks();
		request.setAttribute("books", books);
		return "booklist.jsp";
	}

}
