package com.ssafy.work2.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import day4.work.Book;
import day4.work.BookDAO;

public class SearchController implements Controller {

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 파라미터 검증
		String by = request.getParameter("by");
		String key = request.getParameter("keyword");
		// 모델 연결
		BookDAO dao = BookDAO.getDao();
		List<Book> books = dao.findBook(by, key);
		
		return books.toString();
	}

}
