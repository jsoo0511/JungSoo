import java.io.*;
import java.util.Arrays;
import java.util.Comparator;


public class Main_백준_좌표정렬하기2 {
	 
	public static void main(String[] args) throws IOException{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		
		int num=Integer.parseInt(br.readLine());
		Point p[]=new Point[num];
		for(int i=0;i<num;i++) {
			String s[]=br.readLine().split(" ");
			int x=Integer.parseInt(s[0]);
			int y=Integer.parseInt(s[1]);
			
			p[i]=new Point(x,y);	
		}
		
		Arrays.sort(p,new Comparator<Point>(){

			@Override
			public int compare(Point o1, Point o2) {
				int y1=o1.y;
				int y2=o2.y;
				
				if(y1==y2)
					return Integer.compare(o1.x,o2.x);
				return Integer.compare(y1,y2);
			}
			
		});
		
		for(int i=0;i<num;i++) {
			System.out.println(p[i]);
		}

	}
}
class Point{
	int x;int y;
	Point(int x, int y){
		this.x=x;
		this.y=y;
	}
	
	public String toString() {
		return x+" "+y;
	}
}



