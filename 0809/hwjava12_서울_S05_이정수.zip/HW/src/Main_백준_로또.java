import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class Main_백준_로또 {
	
    static String arr[];
    static int cnt=0;
    static StringBuilder sb;
    static ArrayList<String> a;
	public static void main(String[] args) throws IOException {
		BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
		int k=-1;
		while(true) {
			String s[]=br.readLine().split(" ");
			k=Integer.parseInt(s[0]);
			if(k==0)
				break;
			
			arr=new String[s.length-1];
			for(int i=0;i<arr.length;i++) //배열초기화
				arr[i]=s[i+1];
			for(int i=0;i<=arr.length-6;i++) {
				a=new ArrayList<>();
				cnt=0;
				Back(i);
			}
			System.out.println();
			
		}

	}
	
	public static void Back(int start) {
		//sb.append(arr[start]).append(" ");
		a.add(arr[start]+" ");
		cnt++;
		if (cnt==6) {
			for(String i:a)
				System.out.print(i);
			System.out.println();
			//sb.delete(5,6);
			a.remove(5);
			cnt--;
		} else {
			for(int i=start+1;i<arr.length;i++) {
				Back(i);
			}
			//sb.delete(cnt-1,cnt);
			a.remove(cnt-1);
			cnt--;

		}
	}

}
