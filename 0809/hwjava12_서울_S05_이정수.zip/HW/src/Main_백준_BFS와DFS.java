import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Scanner;
import java.util.Stack;

class Main_백준_BFS와DFS {
	static int arr[][];
	static int N;
	static int V;
	static boolean visited[];
	static boolean visited_B[];
	static ArrayList<Integer>[] list;
	static ArrayList<Integer>[] list_B;
	
	public static void main(String[] args) throws Exception {
		

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		Scanner sc=new Scanner(System.in);
	    String []s=br.readLine().split(" ");
	    N=Integer.parseInt(s[0]);
	    V=Integer.parseInt(s[1]);
	  
	    int start=Integer.parseInt(s[2]);
	    list=new ArrayList[N+1];//(ArrayList<Integer>[])new ArrayList[N+1];
	    list_B=new ArrayList[N+1];
	    visited=new boolean[N+1]; //방문기록
	    visited_B=new boolean[N+1]; //방문기록
	    for(int i=1;i<=N;i++) {
	    	list[i]=new ArrayList<Integer>();
	    	list_B[i]=new ArrayList<Integer>();
	    }
	    
	    for(int i=0;i<V;i++) {
	    	String s1[]=br.readLine().split(" ");
	    	list[Integer.parseInt(s1[0])].add(Integer.parseInt(s1[1]));
	    	list[Integer.parseInt(s1[1])].add(Integer.parseInt(s1[0]));
	    	list_B[Integer.parseInt(s1[0])].add(Integer.parseInt(s1[1]));
	    	list_B[Integer.parseInt(s1[1])].add(Integer.parseInt(s1[0]));
	    	
	    }
	    
	    for(int i=1;i<=N;i++) { //작은순서부터 출력하기 위해 list 오름차순 정렬
	    	Collections.sort(list[i]);
	    	Collections.sort(list_B[i]);
	    }
	   
	    
	    DFS(start);
	    System.out.println();
	    BFS(start);
		

	}
	
	public static void DFS(int start) {
		
		
		visited[start]=true;
		
		System.out.print(start+" ");
		
		for(int x:list[start]) {
			if(!visited[x])
				DFS(x);
		}
	}
	
	public static void BFS(int start) {
		Queue<Integer> q=new LinkedList<>();
		
		q.offer(start);
		visited_B[start]=true;
		
		while(!q.isEmpty()) {
			start=q.poll();
			System.out.print(start+" ");
			for(int x:list_B[start]) {
				if(!visited_B[x]) {
					q.offer(x);
					visited_B[x]=true;
				}
			}
			
		}
		
	}
}
