package com.ssafy.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.ssafy.model.dto.Product;
import com.ssafy.model.service.ProductService;

@Controller
public class ProductController {
	
	@Autowired
	ProductService service;
	
	@GetMapping("/regist")
	public String getRegistPage() {
		return "regist";
	}
	
	@PostMapping("/regist")
	public String Regist(Product product, HttpSession session) {
		session.setAttribute("id", product.getId());
		session.setAttribute("name", product.getName());
		session.setAttribute("price", product.getPrice());
		session.setAttribute("description", product.getDescription());
		
		return "list";
		
	}
	
	@GetMapping("/list")
	public String List() {
		return "list";
	}

}
