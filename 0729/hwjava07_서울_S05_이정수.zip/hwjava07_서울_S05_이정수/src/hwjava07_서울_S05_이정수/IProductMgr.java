package hwjava07_서울_S05_이정수;

import java.util.Collection;


public interface IProductMgr {
	// 상품 삽입
	public boolean addProduct(Product pro);
	public Collection<Product> Search();
	// 3. isbn검색
	public Product Byisbn(String isbn);
	// 4. 상품명 검색
	public Collection<Product> ByName(String name);

	// 5.TV정보만 검색
	public Collection<Product> OnlyTV();
	//6. Refrigerator만 검색
	public Collection<Product> OnlyRe();
	//7. 400L이상 냉장고 검색
	public Collection<Product> Over400();
	//8. 50inch이상 TV검색
	public Collection<Product> Over50();
	//9.상품번호, 상품가격을 입력받아 상품가격변경
	public void ChangePrice(String isbn, int nPrice);
	//10.상품번호로 상품 삭제
	public boolean Delete(String isbn);
	//11.전체 재고상품금액
	public int TotalPrice();
	//12.선택제품별 재고금액
	public int TotalPrice_Want(String kind);
	//13. 파라미터를 전달 받아 각 제품의 재고 수량 출력
	public int TotalNum_Want(String kind);
	//TV재고의 평균인치계산
	public int AvgInch();
	//냉장고의 리터(L)합계
	public int SumL();
	//스마트폰 재고수량 합계
	public int Sum_Remain();
	//파라메터로 상품명,금액을 전달 상품명을 포함하는 상품중 전달된 금액보다 작은 금액의 상품들의 정보를 리턴
	public Collection<Product> underPrice(String name, int price);
}
