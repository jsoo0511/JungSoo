package web_1;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ssafy.model.dto.User;
import com.ssafy.model.repo.UserRepository;

@RunWith(SpringRunner.class)
@ContextConfiguration("classpath:spring/application-config.xml")
@Transactional //테스트 메서드 동작 후 rollback처리
public class DaoTest {

	@Autowired
	UserRepository uRepo;
	
	@Test
	public void test() {

		//Spring에서 sqlSession은 autocommit --> test과정에서는 rollback해버리고 싶다.
		User user=new User(System.currentTimeMillis()+"","테스트","1234",100);
		int result=uRepo.insert(user);
		assertThat(result,is(1));
	}
	
	@Test
	public void selectTest() {
		User user=uRepo.select(new User("hong0",null,null,0));
		assertThat(user.getName(), is("홍길동"));
		
		
		user=uRepo.select(new User("hong0",null,"123",0));
		assertThat(user.getName(), is("홍길동"));
		
//		user=uRepo.select(new User("li",null,null,0));
//		assertThat(user.getName(), is(nullValue()));
	}
	
	@Test
	public void multiTest() {
		List<String> list= Arrays.asList("Hello","Java","World");
		uRepo.multiDel(list);
	}

}
