package com.ssafy.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ssafy.model.dto.User;
import com.ssafy.model.repo.UserRepository;

@Service
public class UserServiceImpl implements UserService{

	
	@Autowired
	UserRepository uRepo;
	
	
	//service의 역할 : transaction처리 & 예외 처리
	
	@Override
	@Transactional //aop기반으로 동작
	//언제 commit이 될까? 별일(RuntimeException) 없었다면...
    //rollback? 별일이 있었다면...
	//예외 처리는 controller에게 위임
	public int join(User user) {
		int result=uRepo.insert(user);
		return result;
	}


	@Override
	public User login(User user) {
		return uRepo.select(user);
	}


	@Override
	public List<User> list() {
		return uRepo.list();
	}


	@Override
	public User detail(User user) {
		return uRepo.select(user);
	}


	@Override
	public int modify(User user) {
		return uRepo.update(user);
	}


	@Override
	public int leave(User user) {
		return uRepo.delete(user);
	}


	@Override
	public int multiDel(List<String> list) {
		return uRepo.multiDel(list);
	}

}
