package com.ssafy.model.service;

import java.util.List;

import com.ssafy.model.dto.User;

public interface UserService {
	int join(User user);
	User login(User user);
	User detail(User user);
	List<User> list();
	int modify(User user);
	int leave(User user);
	int multiDel(List<String> list);
	

}
