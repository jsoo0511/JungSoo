package com.ssafy.model.repo;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ssafy.model.dto.User;

@Repository
public class UserRepositoryImpl implements UserRepository {
	
	private static Logger logger = LoggerFactory.getLogger(UserRepositoryImpl.class);
	private final String ns="com.ssafy.model.UserMapper.";
	
	@Autowired //bean으로 설정해놨으므로 session필요하면 걍 주입받으면 된다.
	SqlSession session;

	@Override
	public int insert(User user) {
		logger.trace("user: {}",user);
		return session.insert(ns+"insert",user);
	}

	@Override
	public User select(User user) {
		logger.trace("user: {}",user);
		return session.selectOne(ns+"select",user);
	}

	@Override
	public List<User> list() {
		logger.trace("list");
		return session.selectList(ns+"list");
	}

	@Override
	public int update(User user) {
		logger.trace("user: {}",user);
		return session.update(ns+"update",user);
	}

	@Override
	public int delete(User user) {
		logger.trace("user: {}",user);
		return session.delete(ns+"delete",user);
	}

	@Override
	public int multiDel(List<String> list) {
		logger.trace("multi: {}",list);
		return session.delete(ns+"multiDel",list);
	}

}
