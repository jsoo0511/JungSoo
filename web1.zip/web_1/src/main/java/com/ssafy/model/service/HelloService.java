package com.ssafy.model.service;

import org.springframework.stereotype.Service;

@Service
public class HelloService {
	
	public String sayHello(String name) {
		return "Hello " + name;
	}
	
	public int calc(int num1, int num2) {
		return num1+num2;
	}
	
	public String Login(String id, String pw) {
		if(id.equals("hong") && pw.equals("1234")) {
			return "success";
			
		} else
			return "fail";
	}
}
