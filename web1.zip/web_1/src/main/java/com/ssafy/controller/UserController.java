package com.ssafy.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.ssafy.model.dto.User;
import com.ssafy.model.service.UserService;

@Controller
public class UserController {

	private static Logger logger = LoggerFactory.getLogger(UserController.class);
	@Autowired
	UserService uService;

	@GetMapping("/regist")
	public String getRegistForm() {
		return "regist";
	}

	@PostMapping("/regist")
	public String doRegist(User user, Model model, RedirectAttributes redir) {
		int result = -1;
		try {
			result = uService.join(user);
			redir.addFlashAttribute("message", "가입성공");
			// 가입 성공시 main.jsp로 이동 P-R-G
			return "redirect:main";
		} catch (RuntimeException e) {
			logger.error("회원가입 실패 ", e);
			model.addAttribute("message", "가입실패");
			return "showMessage";
		}
	}

	// 로그인 폼 요청
	@GetMapping("/login")
	public String getLoginForm() {
		return "login";
	}

	// 로그인 처리
	@PostMapping("/login")
	public String doLogin(User user, Model model, HttpSession session) {
		User loginUser = uService.login(user);
		if (loginUser != null) {
			session.setAttribute("loginUser", loginUser);
			return "redirect:main";
		} else {
			model.addAttribute("message", "아이디/비번 확인필요");
			return "login";
		}
	}

	@GetMapping("/main")
	public String main() {
		return "main";
	}

	@GetMapping("/list")
	public String list(Model model) {
		model.addAttribute("list", uService.list());
		return "list";
	}

	@GetMapping("/detail")
	public String doDetail(User user, Model model) {
		model.addAttribute("details", uService.detail(user));
		return "detail";
	}

	@PostMapping("/modify")
	public String doModify(User user, RedirectAttributes redir) {
		int result = uService.modify(user);
		if (result == 1)
			redir.addFlashAttribute("message", "수정되었습니다.");
		else
			redir.addFlashAttribute("message", "수정실패하였습니다.");
		return "redirect:main";
	}

	@PostMapping("/delete")
	public String doDelete(User user, RedirectAttributes redir) {
		int result = uService.leave(user);
		if (result == 1)
			redir.addFlashAttribute("message", "삭제되었습니다.");
		else
			redir.addFlashAttribute("message", "삭제실패하였습니다.");
		return "redirect:main";
	}

	@GetMapping("/multiDelete")
	public String multiDelete(@RequestParam ArrayList<String> target, RedirectAttributes redir) {
		logger.trace("target: {}", target);
		try {
			uService.multiDel(target);
			redir.addFlashAttribute("message", "삭제되었습니다.");
		} catch (RuntimeException e) {
			logger.error("회원삭제 실패",e);
			redir.addFlashAttribute("message", "삭제실패하였습니다.");
		}
		return "redirect:list";
	}

}
