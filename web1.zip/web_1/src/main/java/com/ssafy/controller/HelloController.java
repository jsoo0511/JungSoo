package com.ssafy.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.ssafy.model.service.HelloService;

@Controller//@MVC에서의 Controller임을 나타내는 annotation //얘는 웹과 관련된 녀석이다. 
public class HelloController {
	
	@Autowired
	HelloService hService;
	
	//FrontController에서 개별 sub controller의 역할 수행
	//Client request --> 분석 --> service --> 데이터 저장 --> view 연결
	
	@RequestMapping(value="/hello", method=RequestMethod.GET)
	public String sayHello(@RequestParam String name, Model model) {  
		String message=hService.sayHello(name); //모델 (Service 연동)
		model.addAttribute("message", message); //뷰를 위한 데이터 저장
		return "showMessage";                   //논리적 뷰 이름 전달
	}
	

}
