package com.ssafy.controller;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;


import com.ssafy.model.dto.User;
import com.ssafy.model.service.HelloService;

//@Controller
//@RequestMapping("/user") 아래에 경로는 /user를 생략해도 /user가 알아서 붙는다. //클레스 레벨 사용: 모든 mapping에 영향
public class MyController {
	//calc.jsp를 화면에 보이자.
	
	@Autowired
	HelloService service;
	
	@GetMapping("/calc")
	public String getCalcForm() {
		//모델연동(Service 연동)
		//뷰를 위한 데이터 저장
		//논리적 뷰 이름 전달
		return "simple/calc";
	}
	
	@PostMapping("/calc")
	public String calc(int num1, int num2, Model model) {
		//모델연동(Service 연동)
		int result=service.calc(num1, num2);
		//뷰를 위한 데이터 저장
		model.addAttribute("result", result);
		//논리적 뷰 이름 전달
		return "simple/calcResult";
	}
	
	@GetMapping("/login")
	public String getLogin() {
		return "login";
	}

//	@PostMapping("/loginByDto")
//	public String loginByDTO(User user, Model model, HttpSession session) {
//		if (user.getId().equals("hong") && user.getPass().equals("1234")) {
//			session.setAttribute("message", user.getId()+"님 반갑습니다.");
////			model.addAttribute("message", user.getId()+"님 반갑습니다");
//			//redirect로 전송하려면 redirect:추가
//			return "redirect:showMessage"; //model은 requestScope이므로 redirect전송시 model이 아니라 session에 담아 넘겨야 한다.
//			//return "showMessage";
//		} else {
//			model.addAttribute("id",user.getId());
//			model.addAttribute("message","id또는 비번을 확인하세요.");
//			return "login";
//		}
//
//	}
	
	@GetMapping("/showMessage")
	public String showMessage() {
		return "showMessage";
	}
	
	@GetMapping("/user/{id}") //user/hong
	public String restAPI(@PathVariable String id, Model model) {
		model.addAttribute("message",id);
		return "showMessage";
	}
	
	@GetMapping("/cookieMaker")
	public String cookieMaker(HttpServletResponse res, Model model) {
		Cookie c = new Cookie("name","홍길동");
		c.setMaxAge(60*3);
		res.addCookie(c);
		model.addAttribute("message","cookie생성완료");
		return "showMessage";
	}
	
	@GetMapping("/cookieConsumer")
	public String cookieConsumer(@CookieValue String name , Model model) {
		//name이란 이름의 쿠키 존재여부 확인
		model.addAttribute("message","쿠키확인: "+name);
		return "showMessage";
	}
	
}
